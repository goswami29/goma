<?php

class Partner_modal extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        $data = array();
        $main_url = site_url('admin/partners/index');
        $url = array();
        $num_rows = $this->db->where('deleteflag', 0)->order_by('sequence', 'asc')->get('partners')->num_rows();

        $page = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);
        if (isset($_GET['per_page']) && !empty($_GET['per_page'])) {
            $per_page = $_GET['per_page'];
            $url[] = 'per_page=' . $per_page;
        } else {
            $per_page = 10;
        }
        $data['page'] = $page;
        $data['num_rows'] = $num_rows;
        $data['per_page'] = $per_page;
        $data['url'] = $main_url . '?' . implode('&', $url) . '&';

        $data['list'] = $this->db->where('deleteflag', 0)->order_by('sequence', 'asc')
            ->get('partners', $per_page, ($per_page * ($page - 1)))->result_array();
        return $data;
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // partner Image Upload
                $image_file_data = upload_image("image", 'uploads/partners/');
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['title'] = $_POST['title'];
                $save['status'] = $_POST['status'];
                $save['add_date'] = date('Y-m-d h:i:s');
                $save['add_by'] = $this->admin['id'];
                $this->db->insert('partners', $save);
                $save_id = $this->db->insert_id();
                return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // partners Upload
                $image_file_data = upload_image("image", 'uploads/partners/');
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['title'] = $_POST['title'];
                $save['status'] = $_POST['status'];
                $save['update_date'] = date('Y-m-d h:i:s');
                $save['update_by'] = $this->admin['id'];
                $this->db->where('id', $id)->update('partners', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view($id)
    {
        return $this->db->select('*')->where('id', $id)->get('partners')->row_array();
    }

    function delete($id)
    {
        $this->db->where('id', $id)->update('partners', array('deleteflag' => 1));
    }

    function organize()
    {
        $slider = $this->input->post('banner');
        $this->set_order($slider);
    }

    function set_order($slider)
    {
        foreach ($slider as $sequence => $id) {
            $data = array('sequence' => $sequence);
            $this->db->where('id', $id);
            $this->db->update('partners', $data);
        }
    }
}
