<?php

class Home_page_content_modal extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->image_path = 'uploads/home_page/';
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('main_title', 'Main Title', 'trim');
            $this->form_validation->set_rules('seo_title', 'SEO Title ', 'trim');
            $this->form_validation->set_rules('seo_keyword', 'SEO Keyword', 'trim');
            $this->form_validation->set_rules('about_heading', 'About Heading', 'trim');
            if ($this->form_validation->run() == TRUE) {
                $save = array();
                $id = isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : 0;
                $edit_data = $this->db->where('id', $id)->get('home_page_content')->row_array();

                // About Image
                $about_image_file_data = upload_image("about_image", $this->image_path, $edit_data['about_image']);
                if (isset($about_image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $about_image_file_data['error'], 'data' => array());
                }
                if (isset($about_image_file_data['name'])) {
                    $save['about_image'] = $about_image_file_data['name'];
                }

                // Learn Study Key Data 
                $learnstudy_key_data = array();
                if (isset($_POST['learnstudy_key_data']['name']) && !empty($_POST['learnstudy_key_data']['name'])) {
                    foreach ($_POST['learnstudy_key_data']['name'] as $key_data_name_key => $key_data_name_val) {
                        $name = $key_data_name_val;
                        $description = (isset($_POST['learnstudy_key_data']['description'][$key_data_name_key]) ? $_POST['learnstudy_key_data']['description'][$key_data_name_key] : "");
                        $url = (isset($_POST['learnstudy_key_data']['url'][$key_data_name_key]) ? $_POST['learnstudy_key_data']['url'][$key_data_name_key] : "");
                        $image = (isset($_POST['learnstudy_key_data']['image'][$key_data_name_key]) ? $_POST['learnstudy_key_data']['image'][$key_data_name_key] : "");
                        $learnstudy_key_data[] = array('name' => $name, "description" => $description, "url" => $url, "image" => $image);
                    }
                }

                if (isset($learnstudy_key_data[0]['name']) && !empty($learnstudy_key_data[0]['name'])) {
                    $save['learnstudy_key_data'] = json_encode($learnstudy_key_data);
                } else {
                    $save['learnstudy_key_data'] = "";
                }

                $save['main_title'] = $this->input->post('main_title');
                $save['seo_title'] = $this->input->post('seo_title');
                $save['seo_keyword'] = $this->input->post('seo_keyword');
                $save['seo_meta_tag'] = $this->input->post('seo_meta_tag');
                $save['about_heading'] = $this->input->post('about_heading');
                $save['about_desc'] = $this->input->post('about_desc');
                $save['projects_completed'] = $this->input->post('projects_completed');
                $save['satisfied_clients'] = $this->input->post('satisfied_clients');
                $save['products'] = $this->input->post('products');
                $save['growth_partner_desc'] = $this->input->post('growth_partner_desc');

                if (isset($edit_data['id']) && !empty($edit_data['id'])) {
                    $save['update_date'] = date('Y-m-d h:i:s');
                    $this->db->where('id', $edit_data['id'])->update('home_page_content', $save);
                } else {
                    $save['add_date'] = date('Y-m-d h:i:s');
                    $this->db->insert('home_page_content', $save);
                }

                return array('status' => 1, 'msg' => "Data Saved Successfully", 'data' => array());
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }
    function view()
    {
        return $this->db->select('*')->get('home_page_content')->row_array();
    }
}
