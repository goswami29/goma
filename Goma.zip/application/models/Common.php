<?php

Class Common extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function get_row_data($table, $group_by = '', $order_by = '', $limit = '', $select = '') {
        if ($select != '') {
            $this->db->select($select);
        }
        if ($group_by != '') {
            $this->db->group_by($group_by);
        }
        if ($order_by != '') {
            $this->db->order_by($order_by);
        }
        if ($limit != '') {
            $this->db->limit($limit);
        }
        return $this->db->get($table)->row_array();
    }

    function manual_query_mod($query) {
        return $this->db->query($query)->result_array();
    }

    function manual_query_mod1($query) {
        return $this->db->query($query);
    }

    function get_data_where($table, $where, $group_by = '', $order_by = '', $limit = 0, $offset = 0, $select = '') {
        if ($select != '') {
            $this->db->select($select);
        }
        if (!empty($where)) {
            foreach ($where as $key => $val) {
                if (is_array($val)) {
                    $s = substr($key, 0, 1);
                    $st = substr($key, 1);
                    if ($s == '!') {
                        $this->db->where_not_in($st, $val);
                    } else {
                        $this->db->where_in($key, $val);
                    }
                } else {
                    $this->db->where($key, $val);
                }
            }
        }
        if ($group_by != '') {
            $this->db->group_by($group_by);
        }
        if ($order_by != '') {
            $this->db->order_by($order_by);
        }
        if (!empty($limit)) {
            $this->db->limit($limit[0], $limit[1]);
        }
        return $this->db->get($table)->result_array();
    }

    function delete_data_where($table, $where) {
        if (!empty($where)) {
            foreach ($where as $key => $val) {
                if (is_array($val)) {
                    $s = substr($key, 0, 1);
                    $st = substr($key, 1);
                    if ($s == '!') {
                        $this->db->where_not_in($st, $val);
                    } else {
                        $this->db->where_in($key, $val);
                    }
                } else {
                    $this->db->where($key, $val);
                }
            }
        }
        return $this->db->delete($table);
    }

    function get_data_where_join($table, $where, $join_table, $Join_coloumn, $join_type) {
        if (!empty($where)) {
            foreach ($where as $key => $val) {
                $this->db->where($table . '.' . $key, $val);
            }
        }
        return $this->db->join($join_table, $table . '.' . $Join_coloumn . '=' . $join_table . '.' . $Join_coloumn)->get($table)->result_array();
    }

    function update_data($data, $where, $table) {
        if (!empty($where)) {
            foreach ($where as $key => $val) {
                if (is_array($val)) {
                    $s = substr($key, 0, 1);
                    $st = substr($key, 1);
                    if ($s == '!') {
                        $this->db->where_not_in($st, $val);
                    } else {
                        $this->db->where_in($key, $val);
                    }
                } else {
                    $this->db->where($key, $val);
                }
            }
        }
        return $this->db->update($table, $data);
    }

    function add_data($data, $table) {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

}
