<?php
class Equipment_modal extends CI_Model
{
    function __construct()
    {
        parent::__construct();
        $this->image_path = 'uploads/equipments/';
    }

    function index()
    {
        $data = array();
        $main_url = site_url('admin/equipments/index');
        $url = array();
        $num_rows = $this->db->where('deleteflag', 0)->order_by('sequence', 'asc')->get('equipments')->num_rows();

        $page = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);
        if (isset($_GET['per_page']) && !empty($_GET['per_page'])) {
            $per_page = $_GET['per_page'];
            $url[] = 'per_page=' . $per_page;
        } else {
            $per_page = 10;
        }
        $data['page'] = $page;
        $data['num_rows'] = $num_rows;
        $data['per_page'] = $per_page;
        $data['url'] = $main_url . '?' . implode('&', $url) . '&';

        $data['list'] = $this->db->select('e.id, e.title, e.image, e.status, cat.name as category_name')
            ->where('deleteflag', 0)->order_by('sequence', 'asc')
            ->join('categories as cat', 'e.category_id = cat.id', 'left')
            ->get('equipments as e', $per_page, ($per_page * ($page - 1)))->result_array();

        return $data;
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('description', 'Description One', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // Image Upload
                $image_file_data = upload_image("image", $this->image_path);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                // Accordion Key Data 
                $accordion_key_data = array();
                if (isset($_POST['accordion_key_data']['name']) && !empty($_POST['accordion_key_data']['name'])) {
                    foreach ($_POST['accordion_key_data']['name'] as $key_data_name_key => $key_data_name_val) {
                        $name = $key_data_name_val;
                        $number = (isset($_POST['accordion_key_data']['number'][$key_data_name_key]) ? $_POST['accordion_key_data']['number'][$key_data_name_key] : "");
                        $description = (isset($_POST['accordion_key_data']['description'][$key_data_name_key]) ? $_POST['accordion_key_data']['description'][$key_data_name_key] : "");
                        $image = (isset($_POST['accordion_key_data']['image'][$key_data_name_key]) ? $_POST['accordion_key_data']['image'][$key_data_name_key] : "");
                        $accordion_key_data[] = array('name' => $name, "number" => $number, "description" => $description, "image" => $image);
                    }
                }

                if (isset($accordion_key_data[0]['name']) && !empty($accordion_key_data[0]['name'])) {
                    $save['accordion_key_data'] = json_encode($accordion_key_data);
                } else {
                    $save['accordion_key_data'] = "";
                }

                $sliderImages = isset($_POST['slider_images']) && !empty($_POST['slider_images']) ? implode(',', $_POST['slider_images']) : "";

                $slug1 = preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['title']);
                $newSlug = strtolower($slug1);

                $save['title'] = $_POST['title'];
                $save['slug'] = $newSlug;
                $save['category_id'] = $_POST['parent_id'];
                $save['whatsapp_number'] = $_POST['whatsapp_number'];
                $save['page_short_desc'] = $_POST['page_short_desc'];
                $save['short_desc'] = $_POST['short_desc'];
                $save['description'] = $_POST['description'];
                $save['description2'] = $_POST['description2'];
                $save['description3'] = $_POST['description3'];
                $save['images'] = $sliderImages;
                $save['advantage_description_one'] = $_POST['advantage_description_one'];
                $save['advantage_description_two'] = $_POST['advantage_description_two'];
                $save['status'] = $_POST['status'];
                $save['add_date'] = date('Y-m-d h:i:s');
                $save['add_by'] = $this->admin['id'];
                $this->db->insert('equipments', $save);
                $save_id = $this->db->insert_id();
                return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim');
            $this->form_validation->set_rules('description', 'Description One', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // Image Upload
                $image_file_data = upload_image("image", $this->image_path);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                // Accordion Key Data 
                $accordion_key_data = array();
                if (isset($_POST['accordion_key_data']['name']) && !empty($_POST['accordion_key_data']['name'])) {
                    foreach ($_POST['accordion_key_data']['name'] as $key_data_name_key => $key_data_name_val) {
                        $name = $key_data_name_val;
                        $number = (isset($_POST['accordion_key_data']['number'][$key_data_name_key]) ? $_POST['accordion_key_data']['number'][$key_data_name_key] : "");
                        $description = (isset($_POST['accordion_key_data']['description'][$key_data_name_key]) ? $_POST['accordion_key_data']['description'][$key_data_name_key] : "");
                        $image = (isset($_POST['accordion_key_data']['image'][$key_data_name_key]) ? $_POST['accordion_key_data']['image'][$key_data_name_key] : "");
                        $accordion_key_data[] = array('name' => $name, "number" => $number, "description" => $description, "image" => $image);
                    }
                }

                if (isset($accordion_key_data[0]['name']) && !empty($accordion_key_data[0]['name'])) {
                    $save['accordion_key_data'] = json_encode($accordion_key_data);
                } else {
                    $save['accordion_key_data'] = "";
                }

                $sliderImages = isset($_POST['slider_images']) && !empty($_POST['slider_images']) ? implode(',', $_POST['slider_images']) : "";

                $slug1 = preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['title']);
                $newSlug = strtolower($slug1);

                $save['title'] = $_POST['title'];
                $save['slug'] = $newSlug;
                $save['category_id'] = $_POST['parent_id'];
                $save['whatsapp_number'] = $_POST['whatsapp_number'];
                $save['page_short_desc'] = $_POST['page_short_desc'];
                $save['short_desc'] = $_POST['short_desc'];
                $save['description'] = $_POST['description'];
                $save['description2'] = $_POST['description2'];
                $save['description3'] = $_POST['description3'];
                $save['images'] = $sliderImages;
                $save['advantage_description_one'] = $_POST['advantage_description_one'];
                $save['advantage_description_two'] = $_POST['advantage_description_two'];
                $save['status'] = $_POST['status'];
                $save['update_date'] = date('Y-m-d h:i:s');
                $save['update_by'] = $this->admin['id'];
                $this->db->where('id', $id)->update('equipments', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view($id)
    {
        return $this->db->select('*')->where('id', $id)->get('equipments')->row_array();
    }

    function delete($id)
    {
        $this->db->where('id', $id)->update('equipments', array('deleteflag' => 1));
    }

    function organize()
    {
        $slider = $this->input->post('banner');
        $this->set_order($slider);
    }

    function set_order($slider)
    {
        foreach ($slider as $sequence => $id) {
            $data = array('sequence' => $sequence);
            $this->db->where('id', $id);
            $this->db->update('equipments', $data);
        }
    }
}
