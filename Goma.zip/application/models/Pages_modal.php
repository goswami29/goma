<?php

class Pages_modal extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->image_path = 'uploads/banners/';
    }

    function index()
    {
        $data = array();
        $data['list'] = $this->db->select('*')->where('status', 1)->get('pages')->result_array();
        return $data;
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', 'Id', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Content', 'trim');
            $this->form_validation->set_rules('seo_title', 'SEO title', 'trim');
            $this->form_validation->set_rules('seo_keyword', 'Keywords', 'trim');
            $this->form_validation->set_rules('meta', 'Meta Data', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $image_file_data = upload_image("banner", $this->image_path);
                if (!isset($image_file_data['error'])) {
                    $save = array();

                    $this->load->helper('text');
                    $slug = (isset($_POST['title']) ? $_POST['title'] : "");
                    if (empty($slug) || $slug == '') {
                        $slug = $_POST['title'];
                    }

                    $slug = url_title(convert_accented_characters($slug), 'dash', TRUE);
                    $route_id = 0;
                    $save['banner'] = $image_file_data['name'];

                    $save['parent_id'] = '0';
                    $save['status'] = '1';
                    $save['type'] = '1';
                    $save['title'] = $_POST['title'];
                    $save['menu_title'] = $_POST['title'];
                    $save['content'] = $_POST['content'];
                    $save['seo_title'] = $_POST['seo_title'];
                    $save['meta'] = $_POST['meta'];
                    $save['seo_keyword'] = $_POST['seo_keyword'];
                    $save['alt_text'] = $_POST['alt_text'];
                    $save['route_id'] = $route_id;
                    $save['slug'] = $slug;
                    $this->db->insert('pages', $save);
                    $save_id = $this->db->insert_id();
                    return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
                } else {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', 'Id', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Content', 'trim');
            $this->form_validation->set_rules('seo_title', 'SEO title', 'trim');
            $this->form_validation->set_rules('seo_keyword', 'Keywords', 'trim');
            $this->form_validation->set_rules('meta', 'Meta Data', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                $edit_data = $this->db->where('id', $id)->get('pages')->row_array();
                $image_file_data = upload_image("banner", $this->image_path, $edit_data['image']);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['banner'] = $image_file_data['name'];
                }

                $this->load->helper('text');
                $slug = (isset($_POST['title']) ? $_POST['title'] : "");
                if (empty($slug) || $slug == '') {
                    $slug = $_POST['title'];
                }

                $slug = url_title(convert_accented_characters($slug), 'dash', TRUE);
                $route_id = 0;
                $save['parent_id'] = '0';
                $save['status'] = '1';
                $save['type'] = '1';
                $save['title'] = $_POST['title'];
                $save['menu_title'] = $_POST['title'];
                $save['content'] = $_POST['content'];
                $save['seo_title'] = $_POST['seo_title'];
                $save['meta'] = $_POST['meta'];
                $save['seo_keyword'] = $_POST['seo_keyword'];
                $save['alt_text'] = $_POST['alt_text'];
                $save['route_id'] = $route_id;
                $save['slug'] = $slug;
                $this->db->where('id', $id)->update('pages', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view($id)
    {
        return $this->db->select('*')->where('id', $id)->get('pages')->row_array();
    }

    function delete($id)
    {
        $where = array('id' => $id);
        $this->db->where($where)->delete('pages');
    }
}
