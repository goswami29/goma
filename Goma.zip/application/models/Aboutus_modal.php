<?php

class Aboutus_modal extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->image_path = 'uploads/about/';
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('main_title', 'Main Title', 'trim|required');
            if ($this->form_validation->run() == TRUE) {
                $save = array();
                $id = isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : 0;
                $edit_data = $this->db->where('id', $id)->get('about_us')->row_array();

                // About Background Image
                $image_file_data = upload_image("image", $this->image_path, $edit_data['image']);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                // Vision Image
                $vision_image_file_data = upload_image("vision_image", $this->image_path, $edit_data['vision_image']);
                if (isset($vision_image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $vision_image_file_data['error'], 'data' => array());
                }
                if (isset($vision_image_file_data['name'])) {
                    $save['vision_image'] = $vision_image_file_data['name'];
                }

                // Mission Image
                $mission_image_file_data = upload_image("mission_image", $this->image_path, $edit_data['mission_image']);
                if (isset($mission_image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $mission_image_file_data['error'], 'data' => array());
                }
                if (isset($mission_image_file_data['name'])) {
                    $save['mission_image'] = $mission_image_file_data['name'];
                }

                // Company Image
                $company_image_file_data = upload_image("company_image", $this->image_path, $edit_data['company_image']);
                if (isset($company_image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $company_image_file_data['error'], 'data' => array());
                }
                if (isset($company_image_file_data['name'])) {
                    $save['company_image'] = $company_image_file_data['name'];
                }

                $save['main_title'] = $this->input->post('main_title');
                $save['seo_title'] = $this->input->post('seo_title');
                $save['seo_keyword'] = $this->input->post('seo_keyword');
                $save['seo_meta_tag'] = $this->input->post('seo_meta_tag');
                $save['heading'] = $this->input->post('heading');
                $save['subheading'] = $this->input->post('subheading');
                $save['button_title'] = $this->input->post('button_title');
                $save['button_url'] = $this->input->post('button_url');
                $save['vision_desc'] = $this->input->post('vision_desc');
                $save['mission_desc'] = $this->input->post('mission_desc');
                $save['company_desc'] = $this->input->post('company_desc');

                if (isset($edit_data['id']) && !empty($edit_data['id'])) {
                    $save['update_date'] = date('Y-m-d h:i:s');
                    $this->db->where('id', $edit_data['id'])->update('about_us', $save);
                } else {
                    $save['add_date'] = date('Y-m-d h:i:s');
                    $this->db->insert('about_us', $save);
                }

                return array('status' => 1, 'msg' => "Data Saved Successfully", 'data' => array());
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }
    function view()
    {
        return $this->db->select('*')->get('about_us')->row_array();
    }
}
