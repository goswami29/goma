<?php

class Category_model extends CI_Model
{
    function get_categories_tierd($category_id = 0, $is_not_admin = false)
    {
        $categories = array();
        $category_list = $this->get_parent_category($category_id, $is_not_admin);
        if (!empty($category_list)) {
            foreach ($category_list as $category_list_key => $category_list_val) {
                $categories[$category_list_key]['category'] = $category_list_val;
                $categories[$category_list_key]['children'] = $this->get_categories_tierd($category_list_val['id'], $is_not_admin);
            }
        }
        return $categories;
    }

    function get_parent_category($parent_id, $is_not_admin)
    {
        $where = array();
        $where['delete_flag'] = 0;
        $where['parent_id'] = 0;

        $select = "id,name,parent_id,slug,active";
        if ($is_not_admin) {
            $select = "id,name,parent_id,image";
            $where['active'] = 1;
        }
        if (!empty($parent_id)) {
            $where['parent_id'] = $parent_id;
        }
        $category = $this->db->select($select)->where($where)
            ->get('categories')->result_array();
        if (!empty($category)) {
            foreach ($category as &$category_val) {
                $category_val['main_parent_id'] = $this->get_category_main_parent_id($category_val['id']);
            }
        }
        return $category;
    }

    function get_category_main_parent_id($id)
    {
        $qurey = "SELECT c1.parent_id as main_parent_id FROM categories as c LEFT JOIN categories as c1 ON c.parent_id = c1.id WHERE c.id = " . $id;
        $result = $this->db->query($qurey)->row_array();
        return (isset($result['main_parent_id']) && !empty($result['main_parent_id']) ? $result['main_parent_id'] : 0);
    }

    function get_category_data($id)
    {
        return $this->db->where('id', $id)->get('categories')->row_array();
    }

    function get_category_filters($category_id)
    {
        $filters = array();
        $category_data = $this->db->select('filters')->where('id', $category_id)->get('categories')->row_array();
        if (isset($category_data['filters']) && !empty($category_data['filters'])) {
            $filters_array = json_decode($category_data['filters'], TRUE);
            if (!empty($filters_array)) {
                foreach ($filters_array as $key => $val) {
                    $temp = array();
                    $lable = $this->db->select('id, title')->where('id', $key)->get('lable')->row_array();
                    $lable_values = $this->db->select('id, value')->where_in('id', $val)->get('lable_values')->result_array();
                    $lable['lable_values'] = $lable_values;
                    $filters[] = $lable;
                }
            }
        }
        return $filters;
    }

    function category()
    {
        return $this->db->select('id,name')->where('delete_flag', 0)->where('parent_id', 0)->get('categories')->result_array();
    }

    function subcategory($id)
    {
        return $this->db->select('id,name')->where('delete_flag', 0)->where('parent_id', $id)->get('categories')->result_array();
    }

    function delete($id)
    {
        $category = array();
        $category['delete_flag'] = '1';

        $this->db->where('id', $id);
        $this->db->update('categories', $category);
    }

    function add_data($data, $table)
    {
        $this->db->insert($table, $data);
        return $insert_id = $this->db->insert_id();
    }

    function update_data($data, $where, $table)
    {
        if (!empty($where)) {
            foreach ($where as $key => $val) {
                if (is_array($val)) {
                    $s = substr($key, 0, 1);
                    $st = substr($key, 1);
                    if ($s == '!') {
                        $this->db->where_not_in($st, $val);
                    } else {
                        $this->db->where_in($key, $val);
                    }
                } else {
                    $this->db->where($key, $val);
                }
            }
        }
        return $this->db->update($table, $data);
    }
}
