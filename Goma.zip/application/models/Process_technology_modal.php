<?php

class Process_technology_modal extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    /*********** Industry Functions **********/

    function index()
    {
        $data = array();
        $data['list'] = $this->db->where('deleteflag', 0)->order_by('sequence', 'asc')->get('process_technology_industry')->result_array();
        return $data;
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Description', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // Image Upload
                $image_file_data = upload_image("image", 'uploads/process_technology/');
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['title'] = $_POST['title'];
                $save['content'] = $_POST['content'];
                $save['status'] = $_POST['status'];
                $save['add_date'] = date('Y-m-d h:i:s');
                $save['add_by'] = $this->admin['id'];
                $this->db->insert('process_technology_industry', $save);
                $save_id = $this->db->insert_id();
                return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Description', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // Image Upload
                $image_file_data = upload_image("image", 'uploads/process_technology/');
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['title'] = $_POST['title'];
                $save['content'] = $_POST['content'];
                $save['status'] = $_POST['status'];
                $save['update_date'] = date('Y-m-d h:i:s');
                $save['update_by'] = $this->admin['id'];
                $this->db->where('id', $id)->update('process_technology_industry', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view($id)
    {
        return $this->db->select('*')->where('id', $id)->get('process_technology_industry')->row_array();
    }

    function delete($id)
    {
        $this->db->where('id', $id)->update('process_technology_industry', array('deleteflag' => 1));
    }

    function organize()
    {
        $slider = $this->input->post('banner');
        $this->set_order($slider);
    }

    function set_order($slider)
    {
        foreach ($slider as $sequence => $id) {
            $data = array('sequence' => $sequence);
            $this->db->where('id', $id);
            $this->db->update('process_technology_industry', $data);
        }
    }

    /*********** Process Technology SEO Functions **********/

    function add_process_technology_seo()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            if ($this->form_validation->run() == TRUE) {
                $save = array();
                $id = isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : 0;
                $edit_data = $this->db->where('id', $id)->get('process_technology_seo')->row_array();

                // Background Image
                $image_file_data = upload_image("image", 'uploads/process_technology/', $edit_data['image']);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['main_title'] = $this->input->post('main_title');
                $save['seo_title'] = $this->input->post('seo_title');
                $save['seo_keyword'] = $this->input->post('seo_keyword');
                $save['seo_meta_tag'] = $this->input->post('seo_meta_tag');
                $save['title'] = $this->input->post('title');
                $save['short_desc'] = $this->input->post('short_desc');
                $save['button_title'] = $this->input->post('button_title');
                $save['button_url'] = $this->input->post('button_url');
                $save['category_title'] = $this->input->post('category_title');
                $save['category_short_desc'] = $this->input->post('category_short_desc');

                if (isset($edit_data['id']) && !empty($edit_data['id'])) {
                    $save['update_date'] = date('Y-m-d h:i:s');
                    $this->db->where('id', $edit_data['id'])->update('process_technology_seo', $save);
                } else {
                    $save['add_date'] = date('Y-m-d h:i:s');
                    $this->db->insert('process_technology_seo', $save);
                }

                return array('status' => 1, 'msg' => "Data Saved Successfully", 'data' => array());
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view_process_technology_seo()
    {
        return $this->db->select('*')->get('process_technology_seo')->row_array();
    }

    /*********** Events Functions **********/

    function events()
    {
        $data = array();
        $data['list'] = $this->db->where('deleteflag', 0)->order_by('sequence', 'asc')->get('process_technology_events')->result_array();
        return $data;
    }

    function add_event()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('event_date_year', 'Event Date & Year', 'trim|required');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Description', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $eventImages = isset($_POST['event_images']) && !empty($_POST['event_images']) ? implode(',', $_POST['event_images']) : "";
                $save = array();
                $save['event_date_year'] = $_POST['event_date_year'];
                $save['title'] = $_POST['title'];
                $save['event_category'] = $_POST['event_category'];
                $save['place'] = $_POST['place'];
                $save['images'] = $eventImages;
                $save['content'] = $_POST['content'];
                $save['show_home'] = $_POST['show_home'];
                $save['status'] = $_POST['status'];
                $save['add_date'] = date('Y-m-d h:i:s');
                $save['add_by'] = $this->admin['id'];
                $this->db->insert('process_technology_events', $save);
                $save_id = $this->db->insert_id();
                return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit_event($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('event_date_year', 'Event Date & Year', 'trim|required');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Description', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $eventImages = isset($_POST['event_images']) && !empty($_POST['event_images']) ? implode(',', $_POST['event_images']) : "";
                $save = array();
                $save['event_date_year'] = $_POST['event_date_year'];
                $save['title'] = $_POST['title'];
                $save['event_category'] = $_POST['event_category'];
                $save['place'] = $_POST['place'];
                $save['images'] = $eventImages;
                $save['content'] = $_POST['content'];
                $save['show_home'] = $_POST['show_home'];
                $save['status'] = $_POST['status'];
                $save['update_date'] = date('Y-m-d h:i:s');
                $save['update_by'] = $this->admin['id'];
                $this->db->where('id', $id)->update('process_technology_events', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view_event($id)
    {
        return $this->db->select('*')->where('id', $id)->get('process_technology_events')->row_array();
    }

    function delete_event($id)
    {
        $this->db->where('id', $id)->update('process_technology_events', array('deleteflag' => 1));
    }

    function organize_event()
    {
        $slider = $this->input->post('banner');
        $this->set_order_event($slider);
    }

    function set_order_event($slider)
    {
        foreach ($slider as $sequence => $id) {
            $data = array('sequence' => $sequence);
            $this->db->where('id', $id);
            $this->db->update('process_technology_events', $data);
        }
    }
}
