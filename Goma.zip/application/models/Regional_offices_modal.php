<?php
class Regional_offices_modal extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        $data = array();
        $main_url = site_url('admin/regional_offices/index');
        $url = array();
        $num_rows = $this->db->where('deleteflag', 0)->get('regional_offices')->num_rows();

        $page = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);
        if (isset($_GET['per_page']) && !empty($_GET['per_page'])) {
            $per_page = $_GET['per_page'];
            $url[] = 'per_page=' . $per_page;
        } else {
            $per_page = 10;
        }
        $data['page'] = $page;
        $data['num_rows'] = $num_rows;
        $data['per_page'] = $per_page;
        $data['url'] = $main_url . '?' . implode('&', $url) . '&';

        $data['list'] = $this->db->where('deleteflag', 0)
            ->get('regional_offices', $per_page, ($per_page * ($page - 1)))->result_array();
        return $data;
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('region', 'Region', 'trim|required');
            $this->form_validation->set_rules('title', 'Region Title', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {
                $officeType = isset($_POST['office_type']) && !empty($_POST['office_type']) ? implode(',', $_POST['office_type']) : "";

                $save = array();
                $save['office_type'] = $officeType;
                $save['region'] = $_POST['region'];
                $save['title'] = $_POST['title'];
                $save['contact_person'] = $_POST['contact_person'];
                $save['phone_no1'] = $_POST['phone_no1'];
                $save['phone_no2'] = $_POST['phone_no2'];
                $save['email1'] = $_POST['email1'];
                $save['email2'] = $_POST['email2'];
                $save['status'] = $_POST['status'];
                $save['add_date'] = date('Y-m-d h:i:s');
                $save['add_by'] = $this->admin['id'];
                $this->db->insert('regional_offices', $save);
                $save_id = $this->db->insert_id();
                return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('region', 'Region', 'trim|required');
            $this->form_validation->set_rules('title', 'Region Title', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {
                $officeType = isset($_POST['office_type']) && !empty($_POST['office_type']) ? implode(',', $_POST['office_type']) : "";

                $save = array();
                $save['office_type'] = $officeType;
                $save['region'] = $_POST['region'];
                $save['title'] = $_POST['title'];
                $save['contact_person'] = $_POST['contact_person'];
                $save['phone_no1'] = $_POST['phone_no1'];
                $save['phone_no2'] = $_POST['phone_no2'];
                $save['email1'] = $_POST['email1'];
                $save['email2'] = $_POST['email2'];
                $save['status'] = $_POST['status'];
                $save['update_date'] = date('Y-m-d h:i:s');
                $save['update_by'] = $this->admin['id'];
                $this->db->where('id', $id)->update('regional_offices', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view($id)
    {
        return $this->db->select('*')->where('id', $id)->get('regional_offices')->row_array();
    }

    function delete($id)
    {
        $this->db->where('id', $id)->update('regional_offices', array('deleteflag' => 1));
    }
}
