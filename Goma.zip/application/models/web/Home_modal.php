<?php

class Home_modal extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function slider()
    {
        return $this->db->select('*')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('slider')->result_array();
    }

    function growth_partners()
    {
        return $this->db->select('title,image')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('partners')->result_array();
    }

    function our_clients()
    {
        return $this->db->select('image')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('clients')->result_array();
    }

    function latest_news()
    {
        return $this->db->select('title,slug,image,short_desc')->where('status', 1)->where('deleteflag', 0)->order_by('id', 'desc')->limit(2)->get('news')->result_array();
    }

    function latest_blogs()
    {
        return $this->db->select('title,slug,image,short_desc')->where('status', 1)->where('deleteflag', 0)->order_by('id', 'desc')->limit(3)->get('blogs')->result_array();
    }

    function testimonials()
    {
        return $this->db->select('id,heading,name,designation,company_name,image,content')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('testimonial')->result_array();
    }

    function awards()
    {
        return $this->db->select('title,image')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('awards')->result_array();
    }

    function home_content()
    {
        return $this->db->select('*')->where('status', 1)->get('home_page_content')->row_array();
    }


    function membership()
    {
        return $this->db->select('*')->where('status', 1)->get('membership_seo')->row_array();
    }

    /***** About Function *****/
    function aboutus()
    {
        return $this->db->select('*')->where('status', 1)->get('about_us')->row_array();
    }

    function about_our_team()
    {
        return $this->db->select('id,name,designation,linkedin,image')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('team')->result_array();
    }

    function about_certifications()
    {
        return $this->db->select('id,title,short_desc,image')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('certifications')->result_array();
    }

    function about_milestones()
    {
        return $this->db->select('id,year,short_desc')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('milestones')->result_array();
    }

    /***** services Function *****/
    function services()
    {
        return $this->db->select('*')->where('status', 1)->get('service_seo')->row_array();
    }

    function services_list()
    {
        return $this->db->select('id,title,content,whatsapp_url,image')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('services')->result_array();
    }

    /***** Blog Functions *****/

    function blog_seo()
    {
        return $this->db->select('*')->where('status', 1)->get('blog_seo')->row_array();
    }

    function blog_list()
    {
        return $this->db->select('b.id, b.title, b.slug, b.short_desc, b.image')
            ->where('b.status', 1)
            ->where('b.deleteflag', 0)
            ->get('blogs as b')->result_array();
    }

    function blog_details($slug)
    {
        return $this->db->select('*')->where('slug', $slug)->where('status', 1)->get('blogs')->row_array();
    }

    function blog_tag_list($tagId)
    {
        return $this->db->select('id, title, slug, short_desc, image')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->like('tag_id', $tagId)
            ->get('blogs')->result_array();
    }

    /************** Contact Us **************/
    function contactus()
    {
        return $this->db->select('*')->where('status', 1)->get('contact_us')->row_array();
    }

    function regional_offices($type)
    {
        return $this->db->select('id,title,contact_person,phone_no1,phone_no2,email1,email2')->where('office_type', $type)->where('status', 1)->where('deleteflag', 0)->get('regional_offices')->result_array();
    }

    function page_content($slug)
    {
        return $this->db->select('*')->where('status', 1)->where('slug', $slug)->get('pages')->row_array();
    }


    /************************Process Technology And Equipment *************************/
    function process_technology_seo()
    {
        return $this->db->select('id,main_title,seo_title,seo_keyword,seo_meta_tag,image,title,short_desc,button_title,button_url,category_title,category_short_desc')->where('status', 1)->get('process_technology_seo')->row_array();
    }

    function process_technology_industry()
    {
        return $this->db->select('id,title,content,image')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('process_technology_industry')->result_array();
    }

    function process_technology_categories()
    {
        $data['categories'] = $pcat = $this->db->select('id,parent_id,name,slug,short_desc,image')->where('parent_id', 0)->where('active', 1)->where('delete_flag', 0)->get('categories')->result_array();
        if (!empty($pcat)) {
            foreach ($pcat as $key => $cat) {
                $data['categories'][$key]['childCategory'] = $this->db->select('*')
                    ->where('parent_id', $cat['id'])
                    ->where('active', 1)
                    ->where('delete_flag', 0)
                    ->get('categories')->result_array();
            }
        }
        return $data;
    }

    function get_process_technology_category_details($slug)
    {
        return $this->db->select('id,name,short_desc,background_image')->where('slug', $slug)->where('active', 1)->where('delete_flag', 0)->get('categories')->row_array();
    }

    function process_technology_equipments($cat_id)
    {
        return $this->db->select('id,title,slug,short_desc,whatsapp_number,image')->where('category_id', $cat_id)->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('equipments')->result_array();
    }

    function equipments_page_description($slug)
    {
        return $this->db->select('*')->where('slug', $slug)->where('status', 1)->get('equipments')->row_array();
    }

    /************** News Functions ****************/

    function news_seo()
    {
        return $this->db->select('*')->where('status', 1)->get('news_seo')->row_array();
    }

    function news_list()
    {
        return $this->db->select('id,title,slug,short_desc,image')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->get('news')->result_array();
    }

    function news_details($slug)
    {
        return $this->db->select('*')->where('slug', $slug)->where('status', 1)->get('news')->row_array();
    }


    /************** Events Functions ****************/

    function event_seo()
    {
        return $this->db->select('*')->where('status', 1)->get('event_seo')->row_array();
    }

    function event_list()
    {
        return $this->db->select('id,title,slug,content,image')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->get('events')->result_array();
    }

    function event_details($slug)
    {
        return $this->db->select('*')->where('slug', $slug)->where('status', 1)->get('events')->row_array();
    }

    function process_technology_events()
    {
        return $this->db->select('id,event_date_year,title,event_category,place,content,images')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->order_by('sequence', 'asc')
            ->get('process_technology_events')->result_array();
    }

    function high_pressure_pumps_events()
    {
        return $this->db->select('id,event_date_year,title,event_category,place,content,images')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->order_by('sequence', 'asc')
            ->get('pressure_pumps_events')->result_array();
    }

    function process_technology_upcoming_events()
    {
        return $this->db->select('id,event_date_year,title,event_category,place,content,images as process_technology_images')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->where('show_home', 1)
            ->order_by('sequence', 'asc')
            ->get('process_technology_events', 3)->result_array();
    }

    function high_pressure_pump_upcoming_events()
    {
        return $this->db->select('id,event_date_year,title,event_category,place,content,images as high_pressure_pump_images')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->where('show_home', 1)
            ->order_by('sequence', 'asc')
            ->get('pressure_pumps_events', 3)->result_array();
    }


    /************************ High Pressure Pumps Functions *************************/

    function pressure_pumps_seo()
    {
        return $this->db->select('id,main_title,seo_title,seo_keyword,seo_meta_tag,image,title,short_desc,button_title,button_url,category_title,category_short_desc')->where('status', 1)->get('pressure_pumps_seo')->row_array();
    }

    function pressure_pumps_industry()
    {
        return $this->db->select('id,title,content,image')->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('pressure_pumps_industry')->result_array();
    }

    function pressure_pumps_categories()
    {
        return $this->db->select('id,name,slug,image')->where('active', 1)->where('delete_flag', 0)->get('pressure_pumps_category')->result_array();
    }

    function get_category_details($slug)
    {
        return $this->db->select('id,name,short_desc,background_image')->where('slug', $slug)->where('active', 1)->where('delete_flag', 0)->get('pressure_pumps_category')->row_array();
    }

    function pressure_pumps_systems($cat_id)
    {
        return $this->db->select('id,title,slug,short_desc,whatsapp_number,image')->where('category_id', $cat_id)->where('status', 1)->where('deleteflag', 0)->order_by('sequence', 'asc')->get('systems')->result_array();
    }

    function system_page_description($slug)
    {
        return $this->db->select('*')->where('slug', $slug)->where('status', 1)->get('systems')->row_array();
    }
}
