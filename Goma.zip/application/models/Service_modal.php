<?php
class Service_modal extends CI_Model
{
    function __construct()
    {
        parent::__construct();
        $this->image_path = 'uploads/service/';
    }

    function add_service_seo()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('title', 'Service Title', 'trim|required');
            if ($this->form_validation->run() == TRUE) {
                $save = array();
                $id = isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : 0;
                $edit_data = $this->db->where('id', $id)->get('service_seo')->row_array();

                // Background Image
                $image_file_data = upload_image("image", $this->image_path, $edit_data['image']);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['main_title'] = $this->input->post('main_title');
                $save['seo_title'] = $this->input->post('seo_title');
                $save['seo_keyword'] = $this->input->post('seo_keyword');
                $save['seo_meta_tag'] = $this->input->post('seo_meta_tag');
                $save['title'] = $this->input->post('title');
                $save['short_desc'] = $this->input->post('short_desc');
                $save['button_title'] = $this->input->post('button_title');
                $save['button_url'] = $this->input->post('button_url');

                if (isset($edit_data['id']) && !empty($edit_data['id'])) {
                    $save['update_date'] = date('Y-m-d h:i:s');
                    $this->db->where('id', $edit_data['id'])->update('service_seo', $save);
                } else {
                    $save['add_date'] = date('Y-m-d h:i:s');
                    $this->db->insert('service_seo', $save);
                }

                return array('status' => 1, 'msg' => "Data Saved Successfully", 'data' => array());
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view_service_seo()
    {
        return $this->db->select('*')->get('service_seo')->row_array();
    }

    /****************** Service Model Functions ******************/

    function index()
    {
        $data = array();
        $main_url = site_url('admin/services/index');
        $url = array();
        $num_rows = $this->db->where('deleteflag', 0)->order_by('sequence', 'asc')->get('services')->num_rows();

        $page = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);
        if (isset($_GET['per_page']) && !empty($_GET['per_page'])) {
            $per_page = $_GET['per_page'];
            $url[] = 'per_page=' . $per_page;
        } else {
            $per_page = 10;
        }
        $data['page'] = $page;
        $data['num_rows'] = $num_rows;
        $data['per_page'] = $per_page;
        $data['url'] = $main_url . '?' . implode('&', $url) . '&';

        $data['list'] = $this->db->where('deleteflag', 0)->order_by('sequence', 'asc')
            ->get('services', $per_page, ($per_page * ($page - 1)))->result_array();
        return $data;
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim');
            $this->form_validation->set_rules('content', 'Content', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // Service Image Upload
                $image_file_data = upload_image("image", $this->image_path);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['title'] = $_POST['title'];
                $save['content'] = $_POST['content'];
                $save['whatsapp_url'] = $_POST['whatsapp_url'];
                $save['status'] = $_POST['status'];
                $save['add_date'] = date('Y-m-d h:i:s');
                $save['add_by'] = $this->admin['id'];
                $this->db->insert('services', $save);
                $save_id = $this->db->insert_id();
                return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Title', 'trim');
            $this->form_validation->set_rules('content', 'content', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // FAQ Icon Upload
                $image_file_data = upload_image("image", $this->image_path);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['title'] = $_POST['title'];
                $save['content'] = $_POST['content'];
                $save['whatsapp_url'] = $_POST['whatsapp_url'];
                $save['status'] = $_POST['status'];
                $save['update_date'] = date('Y-m-d h:i:s');
                $save['update_by'] = $this->admin['id'];
                $this->db->where('id', $id)->update('services', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view($id)
    {
        return $this->db->select('*')->where('id', $id)->get('services')->row_array();
    }

    function delete($id)
    {
        $this->db->where('id', $id)->update('services', array('deleteflag' => 1));
    }

    function organize()
    {
        $slider = $this->input->post('banner');
        $this->set_order($slider);
    }

    function set_order($slider)
    {
        foreach ($slider as $sequence => $id) {
            $data = array('sequence' => $sequence);
            $this->db->where('id', $id);
            $this->db->update('services', $data);
        }
    }

    /**************** Service Enquiry Functions ***************/

    function enquiry_list()
    {
        return $this->db->select('*')->where('deleteflag', 0)->get('service_enquiry')->result_array();
    }

    function view_enquiry($id)
    {
        return $this->db->select('*')->where('id', $id)->get('service_enquiry')->row_array();
    }

    function delete_enquiry($id)
    {
        $this->db->where('id', $id)->update('service_enquiry', array('deleteflag' => 1));
    }
}
