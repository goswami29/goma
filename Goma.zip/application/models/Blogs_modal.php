<?php
class Blogs_modal extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        $data = array();
        $main_url = site_url('admin/blogs/index');
        $url = array();
        $num_rows = $this->db->where('deleteflag', 0)->get('blogs')->num_rows();

        $page = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);
        if (isset($_GET['per_page']) && !empty($_GET['per_page'])) {
            $per_page = $_GET['per_page'];
            $url[] = 'per_page=' . $per_page;
        } else {
            $per_page = 10;
        }
        $data['page'] = $page;
        $data['num_rows'] = $num_rows;
        $data['per_page'] = $per_page;
        $data['url'] = $main_url . '?' . implode('&', $url) . '&';

        $data['list'] = $this->db->where('deleteflag', 0)->get('blogs', $per_page, ($per_page * ($page - 1)))->result_array();
        return $data;
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Blog Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Blog Description', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $slug1 = preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['title']);
                $newSlug = strtolower($slug1);

                $save = array();
                // Blog Image Upload
                $image_file_data = upload_image("image", 'uploads/blogs/');
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }
                $tagIds = isset($_POST['tags']) && !empty($_POST['tags']) ? implode(',', $_POST['tags']) : "";

                $blog_date = $this->input->post('blog_date');
                $save['title'] = $_POST['title'];
                $save['slug'] = $newSlug;
                $save['short_desc'] = $_POST['short_desc'];
                $save['category_id'] = 1;
                $save['tag_id'] = $tagIds;
                $save['content'] = $_POST['content'];
                $save['blog_date'] = date('Y-m-d', strtotime($blog_date));
                $save['status'] = $_POST['status'];
                $save['add_date'] = date('Y-m-d h:i:s');
                $save['add_by'] = $this->admin['id'];
                $this->db->insert('blogs', $save);
                $save_id = $this->db->insert_id();
                return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('title', 'Blog Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Blog Description', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            if ($this->form_validation->run() == TRUE) {

                $slug1 = preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['title']);
                $newSlug = strtolower($slug1);

                $save = array();
                // Blog Image Upload
                $image_file_data = upload_image("image", 'uploads/blogs/');
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }
                $tagIds = isset($_POST['tags']) && !empty($_POST['tags']) ? implode(',', $_POST['tags']) : "";

                $blog_date = $this->input->post('blog_date');
                $save['title'] = $_POST['title'];
                $save['slug'] = $newSlug;
                $save['short_desc'] = $_POST['short_desc'];
                $save['category_id'] = 1;
                $save['tag_id'] = $tagIds;
                $save['content'] = $_POST['content'];
                $save['blog_date'] = date('Y-m-d', strtotime($blog_date));
                $save['status'] = $_POST['status'];
                $save['update_date'] = date('Y-m-d h:i:s');
                $save['update_by'] = $this->admin['id'];
                $this->db->where('id', $id)->update('blogs', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view($id)
    {
        return $this->db->select('*')->where('id', $id)->get('blogs')->row_array();
    }

    function tags()
    {
        return $this->db->select('*')->where('status', 1)->where('delete_flag', 0)->get('tags')->result_array();
    }

    function delete($id)
    {
        $this->db->where('id', $id)->update('blogs', array('deleteflag' => 1));
    }


    /*********** Blog SEO Functions **********/

    function add_blog_seo()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('title', 'Blog Title', 'trim|required');
            if ($this->form_validation->run() == TRUE) {
                $save = array();
                $id = isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : 0;
                $edit_data = $this->db->where('id', $id)->get('blog_seo')->row_array();

                // Background Image
                $image_file_data = upload_image("image", 'uploads/blogs/', $edit_data['image']);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['image'] = $image_file_data['name'];
                }

                $save['main_title'] = $this->input->post('main_title');
                $save['seo_title'] = $this->input->post('seo_title');
                $save['seo_keyword'] = $this->input->post('seo_keyword');
                $save['seo_meta_tag'] = $this->input->post('seo_meta_tag');
                $save['title'] = $this->input->post('title');
                $save['short_desc'] = $this->input->post('short_desc');
                $save['button_title'] = $this->input->post('button_title');
                $save['button_url'] = $this->input->post('button_url');

                if (isset($edit_data['id']) && !empty($edit_data['id'])) {
                    $save['update_date'] = date('Y-m-d h:i:s');
                    $this->db->where('id', $edit_data['id'])->update('blog_seo', $save);
                } else {
                    $save['add_date'] = date('Y-m-d h:i:s');
                    $this->db->insert('blog_seo', $save);
                }

                return array('status' => 1, 'msg' => "Data Saved Successfully", 'data' => array());
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view_blog_seo()
    {
        return $this->db->select('*')->get('blog_seo')->row_array();
    }
}
