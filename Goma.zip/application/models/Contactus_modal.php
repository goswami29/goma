<?php

class Contactus_modal extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->image_path = 'uploads/banners/';
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('main_title', 'Main Title', 'trim|required');
            $this->form_validation->set_rules('contact1', 'Phone 1', 'trim');
            $this->form_validation->set_rules('contact2', 'Phone 2', 'trim');
            $this->form_validation->set_rules('heading', 'Heading', 'trim');
            $this->form_validation->set_rules('email1', 'Email 1', 'trim|valid_email');
            $this->form_validation->set_rules('email2', 'Process Technology Equipment Email', 'trim|valid_email');
            $this->form_validation->set_rules('email3', 'High Pressure Pump Email', 'trim|valid_email');
            $this->form_validation->set_rules('address', 'Address', 'trim');
            $this->form_validation->set_rules('map', 'Map', 'trim');

            if ($this->form_validation->run() == TRUE) {
                $save = array();
                $id = isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : 0;
                $edit_data = $this->db->where('id', $id)->get('contact_us')->row_array();

                $save['main_title'] = $this->input->post('main_title');
                $save['seo_title'] = $this->input->post('seo_title');
                $save['seo_keyword'] = $this->input->post('seo_keyword');
                $save['seo_meta_tag'] = $this->input->post('seo_meta_tag');
                $save['heading'] = $this->input->post('heading');
                $save['contact1'] = $this->input->post('contact1');
                $save['contact2'] = $this->input->post('contact2');
                $save['email1'] = $this->input->post('email1');
                $save['email2'] = $this->input->post('email2');
                $save['email3'] = $this->input->post('email3');
                $save['address'] = $this->input->post('address');
                $save['map'] = $this->input->post('map');

                if (isset($edit_data['id']) && !empty($edit_data['id'])) {
                    $save['update_date'] = date('Y-m-d h:i:s');
                    $this->db->where('id', $edit_data['id'])->update('contact_us', $save);
                } else {
                    $save['add_date'] = date('Y-m-d h:i:s');
                    $this->db->insert('contact_us', $save);
                }

                return array('status' => 1, 'msg' => "Data Saved Successfully", 'data' => array());
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view()
    {
        return $this->db->select('*')->get('contact_us')->row_array();
    }

    function enquiry_list()
    {
        return $this->db->select('*')->where('deleteflag', 0)->get('contact_enquiry')->result_array();
    }

    function contact_enquiry()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('phone', 'Contact no', 'trim|required');
            $this->form_validation->set_rules('company', 'Company', 'trim|required');
            $this->form_validation->set_rules('country', 'Country', 'trim|required');
            $this->form_validation->set_rules('reasons', 'Reasons', 'trim|required');
            $this->form_validation->set_rules('message', 'Message', 'trim');

            if ($this->form_validation->run() == TRUE) {
                $save = array();
                $id = isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : 0;
                $edit_data = $this->db->where('id', $id)->get('contact_enquiry')->row_array();

                $save['name'] = $this->input->post('name');
                $save['email'] = $this->input->post('email');
                $save['phone'] = $this->input->post('phone');
                $save['company'] = $this->input->post('company');
                $save['country'] = $this->input->post('country');
                $save['reasons'] = $this->input->post('reasons');
                $save['message'] = $this->input->post('message');

                if (isset($edit_data['id']) && !empty($edit_data['id'])) {
                    $save['update_date'] = date('Y-m-d h:i:s');
                    $this->db->where('id', $edit_data['id'])->update('contact_enquiry', $save);
                } else {
                    $save['add_date'] = date('Y-m-d h:i:s');
                    $this->db->insert('contact_enquiry', $save);
                }
                return array('status' => 1, 'msg' => "Contact Enquiry Submited Successfully", 'data' => array());
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view_enquiry($id)
    {
        return $this->db->select('*')->where('id', $id)->get('contact_enquiry')->row_array();
    }

    function delete_enquiry($id)
    {
        $this->db->where('id', $id)->update('contact_enquiry', array('deleteflag' => 1));
    }
}
