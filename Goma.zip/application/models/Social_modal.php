<?php

class Social_modal extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        $data = array();
        $main_url = site_url('admin/social/index');
        $url = array();
        $num_rows = $this->db->order_by('sequence', 'asc')->get('social_link')->num_rows();

        $page = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);
        if (isset($_GET['per_page']) && !empty($_GET['per_page'])) {
            $per_page = $_GET['per_page'];
            $url[] = 'per_page=' . $per_page;
        } else {
            $per_page = 10;
        }
        $data['page'] = $page;
        $data['num_rows'] = $num_rows;
        $data['per_page'] = $per_page;
        $data['url'] = $main_url . '?' . implode('&', $url) . '&';

        $data['list'] = $this->db->order_by('sequence', 'asc')
            ->get('social_link', $per_page, ($per_page * ($page - 1)))->result_array();
        return $data;
    }

    function add()
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('name', 'Title', 'trim|required');
            $this->form_validation->set_rules('link', 'Link', 'trim|required');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // Icon Image Upload
                $image_file_data = upload_image("image", 'uploads/social_link/');
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['icon'] = $image_file_data['name'];
                }

                $save['name'] = $_POST['name'];
                $save['link'] = $_POST['link'];
                $save['status'] = $_POST['status'];
                $this->db->insert('social_link', $save);
                $save_id = $this->db->insert_id();
                return array('status' => 1, 'msg' => "Created Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function edit($id)
    {
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('id', '', 'trim');
            $this->form_validation->set_rules('name', 'Title', 'trim|required');
            $this->form_validation->set_rules('link', 'Link', 'trim|required');
            if ($this->form_validation->run() == TRUE) {

                $save = array();
                // Testimonial Image Upload
                $image_file_data = upload_image("image", 'uploads/social_link/');
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $save['icon'] = $image_file_data['name'];
                }

                $save['name'] = $_POST['name'];
                $save['link'] = $_POST['link'];
                $save['status'] = $_POST['status'];
                $this->db->where('id', $id)->update('social_link', $save);
                $save_id = $id;
                return array('status' => 1, 'msg' => "Updated Successfully", 'data' => array('id' => $save_id));
            } else {
                return array('status' => 0, 'msg' => strip_tags(validation_errors()), 'data' => array());
            }
        } else {
            return array('status' => 0, 'msg' => "", 'data' => array());
        }
    }

    function view($id)
    {
        return $this->db->select('*')->where('id', $id)->get('social_link')->row_array();
    }

    function delete($id)
    {
        $this->db->where('id', $id)->delete('social_link');
    }

    function organize()
    {
        $slider = $this->input->post('banner');
        $this->set_order($slider);
    }

    function set_order($slider)
    {
        foreach ($slider as $sequence => $id) {
            $data = array('sequence' => $sequence);
            $this->db->where('id', $id);
            $this->db->update('social_link', $data);
        }
    }
}
