<?php
class Home extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('web/Home_modal');
    }

    public function index()
    {
        $details = $this->Home_modal->home_content();
        //$data['homeContent'] = $details;
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }
        $details['sliders'] = $this->Home_modal->slider();
        $details['growthPartners'] = $this->Home_modal->growth_partners();
        $details['ourClients'] = $this->Home_modal->our_clients();
        $details['latestNews'] = $this->Home_modal->latest_news();
        $details['latestBlogs'] = $this->Home_modal->latest_blogs();
        $details['testimonials'] = $this->Home_modal->testimonials();
        $details['awards'] = $this->Home_modal->awards();

        // Two Event get and merge events and show 
        $process_technology_upcoming_events = $this->Home_modal->process_technology_upcoming_events();
        $high_pressure_pump_upcoming_events = $this->Home_modal->high_pressure_pump_upcoming_events();
        $details['upcoming_events'] = array_merge($process_technology_upcoming_events, $high_pressure_pump_upcoming_events);
        // echo "<pre>";
        // print_r($details['upcoming_events']);
        // die();
        $this->load->view('website/index', $details);
    }

    public function about_us()
    {
        $details = $this->Home_modal->aboutus();
        $details['aboutUs'] = $details;
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }

        $details['our_team'] = $this->Home_modal->about_our_team();
        $details['certifications'] = $this->Home_modal->about_certifications();
        $details['milestones'] = $this->Home_modal->about_milestones();
        // echo "<Pre>";
        // print_r($details);
        // die();
        $this->load->view('website/about_us', $details);
    }

    public function services()
    {
        $details = $this->Home_modal->services();
        $details['services'] = $details;
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }
        $details['services_list'] = $this->Home_modal->services_list();
        $this->load->view('website/services', $details);
    }

    public function services_enquiry()
    {
        $this->form_validation->set_rules('name', 'Full name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('contact', 'Contact', 'trim|required|min_length[7]|max_length[15]|regex_match[/^[0-9]+$/]', array('regex_match' => "Please enter numbers only"));
        $this->form_validation->set_rules('country', 'Country', 'trim|required');
        if ($this->form_validation->run() == TRUE) {
            $post_data = $this->input->post();
            $insert = array();
            $insert['service_title'] = $post_data['service_title'];
            $insert['name'] = $post_data['name'];
            $insert['email'] = $post_data['email'];
            $insert['phone'] = $post_data['contact'];
            $insert['company'] = $post_data['company'];
            $insert['country'] = $post_data['country'];
            $insert['reasons'] = $post_data['reasons'];
            $insert['message'] = $post_data['message'];
            $insert['add_date'] = date('y-m-d H:i:s');
            $this->db->insert('service_enquiry', $insert);

            $email_view = $this->load->view('mail/service_enquiry', $insert, true);
            email_send(ADMIN_CONTACT_US_EMAIL, 'Service Enquiry', $email_view);
            $response_msg = array(
                'status' => 'success',
                'message' => "Thank you for writing to us. We will get back to you shortly."
            );
            echo json_encode($response_msg);
            return false;
        } else {
            $response_msg = array(
                'status' => 'error',
                'message' => strip_tags(validation_errors())
            );
            echo json_encode($response_msg);
            return false;
        }
    }

    public function blog()
    {
        $details = $this->Home_modal->blog_seo();
        $details['blogs'] = $details;
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }

        $details['blog_list'] = $this->Home_modal->blog_list();
        // echo "<Pre>";
        // print_r($details);
        // die();
        $this->load->view('website/blog', $details);
    }

    public function blog_details()
    {
        $slug = $this->uri->segment(2);
        $details = $this->Home_modal->blog_details($slug);
        if (!empty($details)) {
            $this->seo_title = (isset($details['title']) && !empty($details['title']) ? $details['title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }

        // Latest Blogs show in sidebar
        if (!empty($details)) {
            $id = $details['id'];
        } else {
            $id = 0;
        }

        $details['latestBlog'] = $this->db->select('*')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->where_not_in('id', array($id))
            ->order_by('rand()')
            ->limit('2')
            ->get('blogs')->result();

        // All Tags show
        $details['tags'] = $this->db->select('*')
            ->where('status', 1)
            ->where('delete_flag', 0)
            ->get('tags')->result();

        $this->load->view('website/blog_details', $details);
    }

    public function blogs_tag($tagSlug = '')
    {
        $details = $this->Home_modal->blog_seo();
        $details['blogs'] = $details;
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }

        $details['tagName'] = $tag = $this->db->select('id,name')
            ->where('slug', $tagSlug)
            ->get('tags')->row();

        $tagId = (isset($tag) && (!empty($tag))) ? $tag->id : 0;
        $details['blog_list'] = $this->Home_modal->blog_tag_list($tagId);

        $this->load->view('website/blog_tag', $details);
    }

    public function process_technology_equipment()
    {
        $seoDetails['process_technology'] = $seoDetails = $this->Home_modal->process_technology_seo();
        if (!empty($seoDetails)) {
            $this->seo_title = (isset($seoDetails['seo_title']) && !empty($seoDetails['seo_title']) ? $seoDetails['seo_title'] : "");
            $this->seo_keywords = (isset($seoDetails['seo_keyword']) ? $seoDetails['seo_keyword'] : "");
            $this->seo_description = (isset($seoDetails['seo_meta_tag']) ? $seoDetails['seo_meta_tag'] : "");
        }

        $seoDetails['categories'] = $this->Home_modal->process_technology_categories();
        $seoDetails['industries'] = $this->Home_modal->process_technology_industry();
        $seoDetails['testimonials'] = $this->Home_modal->testimonials();
        $seoDetails['latestBlogs'] = $this->Home_modal->latest_blogs();
        $seoDetails['process_technology_events'] = $this->Home_modal->process_technology_events();
        $this->load->view('website/process_technology', $seoDetails);
    }

    public function process_technology_description()
    {
        $slug = $this->uri->segment(2);
        $seoDetails['process_technology'] = $seoDetails = $this->Home_modal->process_technology_seo();
        if (!empty($seoDetails)) {
            $this->seo_title = (isset($seoDetails['seo_title']) && !empty($seoDetails['seo_title']) ? $seoDetails['seo_title'] : "");
            $this->seo_keywords = (isset($seoDetails['seo_keyword']) ? $seoDetails['seo_keyword'] : "");
            $this->seo_description = (isset($seoDetails['seo_meta_tag']) ? $seoDetails['seo_meta_tag'] : "");
        }

        $seoDetails['category'] = $category = $this->Home_modal->get_process_technology_category_details($slug);
        if (isset($category) && !empty($category)) {
            $cat_id = $category['id'];
        } else {
            $cat_id = 0;
        }
        $seoDetails['category_slug'] = $slug;
        $seoDetails['equipmentList'] = $this->Home_modal->process_technology_equipments($cat_id);
        // echo "<pre>";
        // print_r($seoDetails['category']);
        // die();
        $this->load->view('website/process_technology_description', $seoDetails);
    }

    public function process_technology_equipment_page_description()
    {
        $slug = $this->uri->segment(3);
        $seoDetails = $this->Home_modal->process_technology_seo();
        if (!empty($seoDetails)) {
            $this->seo_title = (isset($seoDetails['seo_title']) && !empty($seoDetails['seo_title']) ? $seoDetails['seo_title'] : "");
            $this->seo_keywords = (isset($seoDetails['seo_keyword']) ? $seoDetails['seo_keyword'] : "");
            $this->seo_description = (isset($seoDetails['seo_meta_tag']) ? $seoDetails['seo_meta_tag'] : "");
        }

        $seoDetails['equipments'] = $this->Home_modal->equipments_page_description($slug);
        // echo "<pre>";
        // print_r($seoDetails['equipments']);
        // die();
        $this->load->view('website/equipment_page_description', $seoDetails);
    }

    public function high_pressure_pumps_systems()
    {
        $seoDetails['process_technology'] = $seoDetails = $this->Home_modal->pressure_pumps_seo();
        if (!empty($seoDetails)) {
            $this->seo_title = (isset($seoDetails['seo_title']) && !empty($seoDetails['seo_title']) ? $seoDetails['seo_title'] : "");
            $this->seo_keywords = (isset($seoDetails['seo_keyword']) ? $seoDetails['seo_keyword'] : "");
            $this->seo_description = (isset($seoDetails['seo_meta_tag']) ? $seoDetails['seo_meta_tag'] : "");
        }

        $seoDetails['categories'] = $this->Home_modal->pressure_pumps_categories();
        $seoDetails['industries'] = $this->Home_modal->pressure_pumps_industry();
        $seoDetails['testimonials'] = $this->Home_modal->testimonials();
        $seoDetails['latestBlogs'] = $this->Home_modal->latest_blogs();
        $seoDetails['high_pressure_pumps_events'] = $this->Home_modal->high_pressure_pumps_events();
        // echo "<pre>";
        // print_r($seoDetails['high_pressure_pumps_events']);
        // die();
        $this->load->view('website/high_pressure_pumps', $seoDetails);
    }

    public function high_pressure_pumps_description()
    {
        $slug = $this->uri->segment(2);
        $seoDetails['process_technology'] = $seoDetails = $this->Home_modal->pressure_pumps_seo();
        if (!empty($seoDetails)) {
            $this->seo_title = (isset($seoDetails['seo_title']) && !empty($seoDetails['seo_title']) ? $seoDetails['seo_title'] : "");
            $this->seo_keywords = (isset($seoDetails['seo_keyword']) ? $seoDetails['seo_keyword'] : "");
            $this->seo_description = (isset($seoDetails['seo_meta_tag']) ? $seoDetails['seo_meta_tag'] : "");
        }

        $seoDetails['category'] = $category = $this->Home_modal->get_category_details($slug);
        if (isset($category) && !empty($category)) {
            $cat_id = $category['id'];
        } else {
            $cat_id = 0;
        }
        $seoDetails['category_slug'] = $slug;
        $seoDetails['systemsList'] = $this->Home_modal->pressure_pumps_systems($cat_id);
        $this->load->view('website/pressure_pump_description', $seoDetails);
    }

    public function high_pressure_pump_system_page_description()
    {
        $slug = $this->uri->segment(3);
        $seoDetails = $this->Home_modal->pressure_pumps_seo();
        if (!empty($seoDetails)) {
            $this->seo_title = (isset($seoDetails['seo_title']) && !empty($seoDetails['seo_title']) ? $seoDetails['seo_title'] : "");
            $this->seo_keywords = (isset($seoDetails['seo_keyword']) ? $seoDetails['seo_keyword'] : "");
            $this->seo_description = (isset($seoDetails['seo_meta_tag']) ? $seoDetails['seo_meta_tag'] : "");
        }

        $seoDetails['systems'] = $this->Home_modal->system_page_description($slug);
        // echo "<pre>";
        // print_r($seoDetails['systems']);
        // die();
        $this->load->view('website/pressure_pump_system_page_description', $seoDetails);
    }

    public function news()
    {
        $details = $this->Home_modal->news_seo();
        $details['news'] = $details;
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }

        $details['news_list'] = $this->Home_modal->news_list();
        $this->load->view('website/news', $details);
    }

    public function news_details()
    {
        $slug = $this->uri->segment(2);
        $details = $this->Home_modal->news_details($slug);
        if (!empty($details)) {
            $this->seo_title = (isset($details['title']) && !empty($details['title']) ? $details['title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }

        // Latest News show in sidebar
        if (!empty($details)) {
            $id = $details['id'];
        } else {
            $id = 0;
        }

        $details['latestNews'] = $this->db->select('*')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->where_not_in('id', array($id))
            ->order_by('rand()')
            ->limit('2')
            ->get('news')->result();

        $this->load->view('website/news_details', $details);
    }

    // Events
    public function events()
    {
        $details = $this->Home_modal->event_seo();
        //$details['events'] = $details;
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }

        $details['event_list'] = $this->Home_modal->event_list();
        $details['process_technology_events'] = $this->Home_modal->process_technology_events();
        $details['high_pressure_pumps_events'] = $this->Home_modal->high_pressure_pumps_events();
        $this->load->view('website/events', $details);
    }

    public function event_details()
    {
        $slug = $this->uri->segment(2);
        $details = $this->Home_modal->event_details($slug);
        if (!empty($details)) {
            $this->seo_title = (isset($details['title']) && !empty($details['title']) ? $details['title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }

        // Latest Event show in sidebar
        if (!empty($details)) {
            $id = $details['id'];
        } else {
            $id = 0;
        }

        $details['latestEvent'] = $this->db->select('*')
            ->where('status', 1)
            ->where('deleteflag', 0)
            ->where_not_in('id', array($id))
            ->order_by('rand()')
            ->limit('2')
            ->get('events')->result();

        $this->load->view('website/event_details', $details);
    }


    public function contact()
    {
        $details = $this->Home_modal->contactus();
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['seo_meta_tag']) ? $details['seo_meta_tag'] : "");
        }
        $type = 1;
        $details['regional_offices'] = $this->Home_modal->regional_offices($type);
        $this->load->view('website/contact_us', $details);
    }

    public function search_contact()
    {
        $response = array();
        $regionType = $_POST['regionType'];
        $officeType = isset($_POST['officeType']) && !empty($_POST['officeType']) ? implode(',', $_POST['officeType']) : "";

        $seoDetails['regional_offices'] = $seoDetails = $this->db->select('id,title,contact_person,phone_no1,phone_no2,email1,email2')->where('status', 1)->where('deleteflag', 0)->like('office_type', $officeType)->like('region', $regionType)->get('regional_offices')->result_array();
        $view = $this->load->view('website/search_regionl_office', $seoDetails, true);
        $response['show_result'] = $view;
        echo json_encode($response);
    }

    public function save_contact_data()
    {
        $this->form_validation->set_rules('name', 'Full name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('contact', 'Contact', 'trim|required|min_length[7]|max_length[15]|regex_match[/^[0-9]+$/]', array('regex_match' => "Please enter numbers only"));
        $this->form_validation->set_rules('country', 'Country', 'trim|required');
        if ($this->form_validation->run() == TRUE) {
            $post_data = $this->input->post();
            $insert = array();
            $insert['name'] = $post_data['name'];
            $insert['email'] = $post_data['email'];
            $insert['phone'] = $post_data['contact'];
            $insert['company'] = $post_data['company'];
            $insert['country'] = $post_data['country'];
            $insert['reasons'] = $post_data['reasons'];
            $insert['message'] = $post_data['message'];
            $insert['add_date'] = date('y-m-d H:i:s');
            $this->db->insert('contact_enquiry', $insert);

            $email_view = $this->load->view('mail/contact_us_enquiry', $insert, true);
            email_send(ADMIN_CONTACT_US_EMAIL, 'Contact Enquiry', $email_view);
            $response_msg = array(
                'status' => 'success',
                'message' => "Thank you for writing to us. We will get back to you shortly."
            );
            echo json_encode($response_msg);
            return false;
        } else {
            $response_msg = array(
                'status' => 'error',
                'message' => strip_tags(validation_errors())
            );
            echo json_encode($response_msg);
            return false;
        }
    }

    public function subscribe()
    {
        $email = $this->input->post('email_id');
        $this->form_validation->set_rules('email_id', 'Email', 'trim|required|valid_email', array('valid_email' => 'Email must be valid.'));
        if ($this->form_validation->run() == TRUE) {
            $data1 = array(
                'email' => $email,
                'add_date' => date('Y-m-d h:i:s')
            );
            add_data($data1, 'subscribe');
            $msg['success'] = 'You have subscribe successfully';
        } else {
            $msg['error'] = strip_tags(validation_errors());
        }
        echo json_encode($msg);
    }

    public function privacy_term_page()
    {
        $slug = $this->uri->segment(2);
        $details = $this->Home_modal->page_content($slug);
        //$details['privacyPolicy'] = $details;
        if (!empty($details)) {
            $this->seo_title = (isset($details['seo_title']) && !empty($details['seo_title']) ? $details['seo_title'] : "");
            $this->seo_keywords = (isset($details['seo_keyword']) ? $details['seo_keyword'] : "");
            $this->seo_description = (isset($details['meta']) ? $details['meta'] : "");
        }

        $this->load->view('website/policy_page', $details);
    }

    public function career()
    {
        $this->load->view('website/career');
    }

    public function save_career()
    {
        $this->form_validation->set_rules('name', 'Full name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('contact', 'Contact', 'trim|required|min_length[7]|max_length[15]|regex_match[/^[0-9]+$/]', array('regex_match' => "Please enter numbers only"));

        if ($this->form_validation->run() == TRUE) {
            $post_data = $this->input->post();
            $insert = array();
            // Upload CV
            $file_data = upload_pdf("cv_file", 'uploads/career/');
            if (isset($file_data['error'])) {
                return array('status' => 0, 'msg' =>  $file_data['error'], 'data' => array());
            }
            if (isset($file_data['name'])) {
                $insert['cv_file'] = $file_data['name'];
                $file_path = base_url('uploads/career/' . $insert['cv_file']);
            } else {
                $file_path = '';
            }

            $insert['name'] = $post_data['name'];
            $insert['email'] = $post_data['email'];
            $insert['phone'] = $post_data['contact'];
            $insert['appling_for'] = $post_data['appling_for'];
            $insert['cv_file'] = $file_path;
            $insert['message'] = $post_data['message'];
            $insert['add_date'] = date('y-m-d H:i:s');
            $this->db->insert('career_enquiry', $insert);

            $email_view = $this->load->view('mail/career_enquiry', $insert, true);
            email_send(ADMIN_CONTACT_US_EMAIL, 'Career Enquiry', $email_view);
            $response_msg = array(
                'status' => 'success',
                'message' => "Thank you for writing to us. We will get back to you shortly."
            );
            echo json_encode($response_msg);
            return false;
        } else {
            $response_msg = array(
                'status' => 'error',
                'message' => strip_tags(validation_errors())
            );
            echo json_encode($response_msg);
            return false;
        }
    }
}
