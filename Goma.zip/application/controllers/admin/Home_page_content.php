<?php

class Home_page_content extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Home_page_content_modal');
    }

    public function index()
    {
        $data = array();
        $data['active_tab'] = 1;
        $data['sub_active'] = 10;
        $data['page_title'] = "Home Page Content";

        $detail = $this->Home_page_content_modal->view();
        $add_response = $this->Home_page_content_modal->add();
        //echo "<pre>";
        //print_r($add_response);
        //die();

        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/home_page_content');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $data['redirect_url'] = 'admin/dynamic_content';
        $this->load->view('admin/pages/home_page_content', $data);
    }

    function upload_key_data_images()
    {
        $images = array();
        $upload_path = 'uploads/home_page/';
        if (isset($_FILES) && !empty($_FILES)) {
            foreach ($_FILES as $files_val) {
                $_FILES['image']['name'] = time() . '_' . str_replace(' ', '_', $files_val['name']);
                $_FILES['image']['type'] = $files_val['type'];
                $_FILES['image']['tmp_name'] = $files_val['tmp_name'];
                $_FILES['image']['error'] = $files_val['error'];
                $_FILES['image']['size'] = $files_val['size'];

                $image_file_data = upload_image("image", $upload_path);
                if (isset($image_file_data['error'])) {
                    $images['file_error'][] = $image_file_data['error'];
                } else if (isset($image_file_data['name'])) {
                    $images['file_name'][] = $image_file_data['name'];
                }
            }
        }
        echo json_encode($images);
    }
}
