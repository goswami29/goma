<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Categories extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Category_model');
    }

    public function index()
    {
        $data = array();
        $data['active_tab'] = 6;
        $data['sub_active'] = 62;
        $data['page_title'] = "Category List";
        $data['categories'] = $this->Category_model->get_categories_tierd();
        $this->load->view('admin/process_technology/category/list', $data);
    }

    function delete($id)
    {
        $check_category_id = isset($id) && !empty($id) ? $id : 0;
        $catid = substr(safe_b64decode($check_category_id), 8);
        $category = $this->Category_model->get_category_data($catid);
        if (!empty($category)) {
            $this->Category_model->delete($catid);
            $this->session->set_flashdata('err', "Category deleted successfully.");
            redirect('admin/categories');
        } else {
            $this->session->set_flashdata('err', "something went wrong.category not deleted.");
            redirect('admin/categories');
        }
    }

    public function add($category_id_ency = 0)
    {
        $data = array();
        $data['active_tab'] = 6;
        $data['sub_active'] = 62;
        $data['page_title'] = "Category Form";
        $category_id = (isset($category_id_ency) && !empty($category_id_ency) ? $category_id_ency : 0);
        $catid = substr(safe_b64decode($category_id), 8);
        $edit_data = $this->Category_model->get_category_data($catid);

        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('name', 'Category name', 'trim|required|max_length[64]');
            if (empty($edit_data)) {
                $this->form_validation->set_rules('parent_id', 'parent category', 'trim|required');
            }
            if ($this->form_validation->run() == TRUE) {
                $data1 = array();
                $slug1 = preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['name']);
                $newSlug = strtolower($slug1);
                $data1 = array(
                    'name' => $_POST['name'],
                    'short_desc' => $_POST['short_desc'],
                    'slug' => $newSlug,
                    'active' => $_POST['active']
                );

                // Category Image
                $image_file_data = upload_image("image", 'uploads/category', $edit_data['image']);
                if (isset($image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $image_file_data['error'], 'data' => array());
                }
                if (isset($image_file_data['name'])) {
                    $data1['image'] = $image_file_data['name'];
                }

                // Category Background Image
                $bg_image_file_data = upload_image("background_image", 'uploads/category', $edit_data['background_image']);
                if (isset($bg_image_file_data['error'])) {
                    return array('status' => 0, 'msg' =>  $bg_image_file_data['error'], 'data' => array());
                }
                if (isset($bg_image_file_data['name'])) {
                    $data1['background_image'] = $bg_image_file_data['name'];
                }

                if (isset($_POST['id']) && !empty($_POST['id'])) {
                    $this->Category_model->update_data($data1, array('id' => $_POST['id']), 'categories');
                    $this->session->set_flashdata('msg', 'Category Updated Successfully !!!');
                } else {
                    $data1['parent_id'] = $_POST['parent_id'];
                    $this->Category_model->add_data($data1, 'categories');
                    $this->session->set_flashdata('msg', 'Category Added Successfully !!!');
                }

                redirect('admin/categories');
                return false;
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $edit_data);
        $data['update_flag'] = (!empty($edit_data) ? 1 : 0);
        $data['categories'] = $this->Category_model->get_categories_tierd();
        $data['redirect_url'] = 'admin/categories';
        $this->load->view('admin/process_technology/category/add', $data);
    }
}
