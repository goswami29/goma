<?php
class Dashboard extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
    }

    public function index()
    {
        $data = array();
        $data['active_tab'] = 50;
        $data['sub_active'] = 0;
        $this->load->view('admin/dashboard', $data);
    }
}
