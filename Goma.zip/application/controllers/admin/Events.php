<?php

class Events extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Events_modal');
    }

    /******** Event Seo Function ********/
    public function page()
    {
        $data = array();
        $data['active_tab'] = 8;
        $data['sub_active'] = 80;
        $data['page_title'] = "Event Page";

        $detail = $this->Events_modal->view_event_seo();
        $add_response = $this->Events_modal->add_event_seo();

        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/events/page');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }

        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $this->load->view('admin/event/event_page', $data);
    }

    public function index()
    {
        $data = $this->Events_modal->index();
        $data['active_tab'] = 9;
        $data['sub_active'] = 90;
        $data['page_title'] = "Events";
        $this->load->view('admin/event/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 9;
        $data['sub_active'] = 90;
        $data['page_title'] = "Event Form";
        $add_response = $this->Events_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/events');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/events';
        $this->load->view('admin/event/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Events_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 9;
            $data['sub_active'] = 90;
            $data['page_title'] = "Edit Event";
            $edit_response = $this->Events_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/events');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/events';
            $this->load->view('admin/event/edit', $data);
        } else {
            redirect('admin/events');
        }
    }

    public function organize()
    {
        $this->Events_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Events_modal->view($id);
        if (!empty($detail)) {
            $this->Events_modal->delete($id);
            $this->session->set_flashdata('msg', "Event Deleted");
            redirect('admin/events');
        } else {
            redirect('admin/events');
        }
    }
}
