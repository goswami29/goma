<?php

class Profile extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
    }

    public function index()
    {
        $data = array();
        $adminID = $this->admin['id'];
        $data['userDetails'] = $user_data = $this->db->select('name,email,p')->where('id', $adminID)->get('users')->row_array();
        if (isset($_POST['saveProfile']) && !empty($_POST['saveProfile'])) {
            $updateData = array();
            $updateData['name'] = $_POST['name'];
            $updateData['email'] = $_POST['email'];
            if (isset($updateData) && !empty($updateData)) {
                update_data($updateData, array('id' => $adminID), 'users');
                $this->session->set_flashdata('msg', 'Data Save Successfully.');
                redirect('admin/profile');
            }
        }
        if (isset($_POST['savePassword']) && !empty($_POST['savePassword'])) {
            $this->form_validation->set_rules('oldpassword', 'old password', 'trim|required');
            $this->form_validation->set_rules('newpassword', 'new password', 'trim|required|min_length[6]|matches[confirmpassword]');
            $this->form_validation->set_rules('confirmpassword', 'confirm password', 'trim|min_length[6]|required');
            if ($this->form_validation->run() == TRUE) {
                $oldpassword = $this->input->post('oldpassword');
                $newpassword = $this->input->post('newpassword');
                $confirmpassword = $this->input->post('confirmpassword');
                if ($newpassword == $confirmpassword) {
                    if ($oldpassword == $user_data['p']) {
                        $save = array();
                        $save['password'] = md5($newpassword);
                        $save['p'] = $newpassword;
                        update_data($save, array('id =' => $adminID), 'users');
                        $this->session->set_flashdata('msg', 'Password changed successfully.');
                        redirect('admin/profile');
                    } else {
                        $this->session->set_flashdata('err', 'The old password is incorrect.');
                        redirect('admin/profile');
                    }
                } else {
                    $this->session->set_flashdata('err', 'The new password field does not match the confirm password field.');
                    redirect('admin/profile');
                }
            } else {
                $this->session->set_flashdata('err', strip_tags(validation_errors()));
                redirect('admin/profile');
            }
        }
        $this->load->view('admin/profile', $data);
    }
}
