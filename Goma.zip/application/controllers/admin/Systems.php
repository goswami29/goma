<?php

class Systems extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Systems_modal');
    }

    public function index()
    {
        $data = $this->Systems_modal->index();
        $data['active_tab'] = 7;
        $data['sub_active'] = 73;
        $data['page_title'] = "Product List";
        $this->load->view('admin/pressure_pumps/systems/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 7;
        $data['sub_active'] = 73;
        $data['page_title'] = "Product Form";
        $add_response = $this->Systems_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/systems');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/systems';
        $data['categories'] = $this->Systems_modal->get_categories();
        $this->load->view('admin/pressure_pumps/systems/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Systems_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 7;
            $data['sub_active'] = 73;
            $data['page_title'] = "Edit Product";
            $edit_response = $this->Systems_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/systems');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/systems';
            $data['categories'] = $this->Systems_modal->get_categories();
            $this->load->view('admin/pressure_pumps/systems/edit', $data);
        } else {
            redirect('admin/systems');
        }
    }

    public function organize()
    {
        $this->Systems_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Systems_modal->view($id);
        if (!empty($detail)) {
            $this->Systems_modal->delete($id);
            $this->session->set_flashdata('msg', "Product Deleted");
            redirect('admin/systems');
        } else {
            redirect('admin/systems');
        }
    }

    function upload_key_data_images()
    {
        $images = array();
        $upload_path = 'uploads/systems/';
        if (isset($_FILES) && !empty($_FILES)) {
            foreach ($_FILES as $files_val) {
                $_FILES['image']['name'] = time() . '_' . str_replace(' ', '_', $files_val['name']);
                $_FILES['image']['type'] = $files_val['type'];
                $_FILES['image']['tmp_name'] = $files_val['tmp_name'];
                $_FILES['image']['error'] = $files_val['error'];
                $_FILES['image']['size'] = $files_val['size'];

                $image_file_data = upload_image("image", $upload_path);
                if (isset($image_file_data['error'])) {
                    $images['file_error'][] = $image_file_data['error'];
                } else if (isset($image_file_data['name'])) {
                    $images['file_name'][] = $image_file_data['name'];
                }
            }
        }
        echo json_encode($images);
    }

    function upload_slider_images()
    {
        if (isset($_FILES) && !empty($_FILES)) {
            $cnt = count($_FILES);
            $_FILES['event_image_file'] = array();
            for ($i = 0; $i < $cnt; $i++) {
                $_FILES['event_image_file']['name'][$i] = $_FILES[$i]['name'];
                $_FILES['event_image_file']['type'][$i] = $_FILES[$i]['type'];
                $_FILES['event_image_file']['tmp_name'][$i] = $_FILES[$i]['tmp_name'];
                $_FILES['event_image_file']['error'][$i] = $_FILES[$i]['error'];
                $_FILES['event_image_file']['size'][$i] = $_FILES[$i]['size'];
            }
        }
        $path = 'uploads/systems/';
        $files = $_FILES['event_image_file'];
        $title = "";
        $images = array();
        $images = $this->upload_files_to_folder($path, $title, $files);
        echo json_encode($images);
    }

    function upload_files_to_folder($path, $title, $files)
    {
        $return = array();
        $config = array(
            'upload_path' => $path,
            'allowed_types' => '*',
            'overwrite' => 1,
            'remove_spaces' => TRUE,
            'encrypt_name' => TRUE
        );

        $this->load->library('upload', $config);
        $images = array();
        $msg = array();
        foreach ($files['name'] as $key => $image) {
            $_FILES['images[]']['name'] = $files['name'][$key];
            $_FILES['images[]']['type'] = $files['type'][$key];
            $_FILES['images[]']['tmp_name'] = $files['tmp_name'][$key];
            $_FILES['images[]']['error'] = $files['error'][$key];
            $_FILES['images[]']['size'] = $files['size'][$key];

            $fileName = time() . '_' . str_replace(' ', '_', $image);
            $config['file_name'] = $fileName;
            $this->upload->initialize($config);
            if ($this->upload->do_upload('images[]')) {
                $file_info = $this->upload->data();
                $images[] = $file_info['file_name'];
                $status = 1;
            } else {
                $status = 0;
                $msg[] = $this->upload->display_errors();
            }
        }
        $return['status'] = $status;
        $return['msg'] = $msg;
        $return['image'] = $images;
        return $return;
    }
}
