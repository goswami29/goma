<?php

class Blogs extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Blogs_modal');
    }

    public function index()
    {
        $data = $this->Blogs_modal->index();
        $data['active_tab'] = 5;
        $data['sub_active'] = 106;
        $data['page_title'] = "Blog List";
        $data['tagList'] = $this->Blogs_modal->tags();
        $this->load->view('admin/blogs/index', $data);
    }
    public function add()
    {
        $data = array();
        $data['active_tab'] = 5;
        $data['sub_active'] = 106;
        $data['page_title'] = "Blog Form";
        $add_response = $this->Blogs_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/blogs');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/blogs';
        $data['tagList'] = $this->Blogs_modal->tags();
        $this->load->view('admin/blogs/add', $data);
    }
    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Blogs_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 5;
            $data['sub_active'] = 106;
            $data['page_title'] = "Edit Blog";
            $edit_response = $this->Blogs_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/blogs');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/blogs';
            $data['tagList'] = $this->Blogs_modal->tags();
            $this->load->view('admin/blogs/edit', $data);
        } else {
            redirect('admin/blogs');
        }
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Blogs_modal->view($id);
        if (!empty($detail)) {
            $this->Blogs_modal->delete($id);
            $this->session->set_flashdata('msg', "Blog Deleted");
            redirect('admin/blogs');
        } else {
            redirect('admin/blogs');
        }
    }

    /******** Blog Seo Function ********/
    public function page()
    {
        $data = array();
        $data['active_tab'] = 5;
        $data['sub_active'] = 104;
        $data['page_title'] = "Blog Page";

        $detail = $this->Blogs_modal->view_blog_seo();
        $add_response = $this->Blogs_modal->add_blog_seo();

        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/blogs/page');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }

        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $this->load->view('admin/blogs/blog_page', $data);
    }
}
