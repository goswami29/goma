<?php

class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    /* public function index() {

        if (!empty(admin_login_data())) {
            redirect('admin/dashboard');
        }
        $data = array();
        if (!empty($_POST)) {
            $this->form_validation->set_rules('user_name', 'User name', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            if ($this->form_validation->run() == TRUE) {
                $user = $this->db->select('id')->where(array('user_name' => $_POST['user_name'], 'password' => md5($_POST['password'])))->get('admin_login')->row_array();
                if (!empty($user)) {
                    $update_array = array();
                    $update_array['login_token'] = generate_string_key(10, 'admin_login', 'login_token');
                    $update_array['last_login_time'] = date("Y-m-d H:i:s");
                    $update_array['last_login_ip_address'] = get_client_ip();
                    $this->db->update('admin_login', $update_array);

                    $this->session->set_userdata('admin_login_token', $update_array['login_token']);
                    redirect("admin/dashboard");
                } else {
                    $data['error'] = "Invalid Username or Password";
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }
        $this->load->view('admin/login', $data);
    }  */

    public function index()
    {

        if (!empty(admin_login_data())) {
            redirect('admin/dashboard');
        }
        $data = array();
        if (!empty($_POST)) {
            $this->form_validation->set_rules('email', 'Email', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            if ($this->form_validation->run() == TRUE) {
                $user = $this->db->select('id,name')->where(array('email' => $_POST['email'], 'password' => md5($_POST['password'])))->get('users')->row_array();
                if (!empty($user)) {
                    $this->session->set_userdata('admin_login_token', $user);
                    redirect("admin/dashboard");
                } else {
                    $data['error'] = "Invalid Email or Password";
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }
        $this->load->view('admin/login', $data);
    }

    function logout()
    {
        $this->session->unset_userdata('admin_login_token');
        redirect('admin/login');
    }
}
