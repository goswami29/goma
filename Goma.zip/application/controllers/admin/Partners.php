<?php

class Partners extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Partner_modal');
    }

    public function index()
    {
        $data = $this->Partner_modal->index();
        $data['active_tab'] = 1;
        $data['sub_active'] = 15;
        $data['page_title'] = "Growth Partner List";
        $this->load->view('admin/partners/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 1;
        $data['sub_active'] = 15;
        $data['page_title'] = "Growth Partner Form";
        $add_response = $this->Partner_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/partners');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/partners';
        $this->load->view('admin/partners/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Partner_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 1;
            $data['sub_active'] = 15;
            $data['page_title'] = "Edit Growth Partner";
            $edit_response = $this->Partner_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/partners');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/partners';
            $this->load->view('admin/partners/edit', $data);
        } else {
            redirect('admin/partners');
        }
    }

    public function organize()
    {
        $this->Partner_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Partner_modal->view($id);
        if (!empty($detail)) {
            $this->Partner_modal->delete($id);
            $this->session->set_flashdata('msg', "Growth Partner Deleted");
            redirect('admin/partners');
        } else {
            redirect('admin/partners');
        }
    }
}
