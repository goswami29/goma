<?php

class Milestones extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Milestone_modal');
    }

    public function index()
    {
        $data = $this->Milestone_modal->index();
        $data['active_tab'] = 2;
        $data['sub_active'] = 23;
        $data['page_title'] = "Milestone List";
        $this->load->view('admin/about/milestone/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 2;
        $data['sub_active'] = 23;
        $data['page_title'] = "Milestone Form";
        $add_response = $this->Milestone_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/milestones');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/milestones';
        $this->load->view('admin/about/milestone/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Milestone_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 2;
            $data['sub_active'] = 23;
            $data['page_title'] = "Edit Milestone";
            $edit_response = $this->Milestone_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/milestones');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/milestones';
            $this->load->view('admin/about/milestone/edit', $data);
        } else {
            redirect('admin/milestones');
        }
    }

    public function organize()
    {
        $this->Milestone_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Milestone_modal->view($id);
        if (!empty($detail)) {
            $this->Milestone_modal->delete($id);
            $this->session->set_flashdata('msg', "Milestone Deleted");
            redirect('admin/milestones');
        } else {
            redirect('admin/milestones');
        }
    }
}
