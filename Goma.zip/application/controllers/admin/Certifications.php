<?php

class Certifications extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Certification_modal');
    }

    public function index()
    {
        $data = $this->Certification_modal->index();
        $data['active_tab'] = 2;
        $data['sub_active'] = 22;
        $data['page_title'] = "Certification List";
        $this->load->view('admin/about/certification/index', $data);
    }
    public function add()
    {
        $data = array();
        $data['active_tab'] = 2;
        $data['sub_active'] = 22;
        $data['page_title'] = "Certification Form";
        $add_response = $this->Certification_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/certifications');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/certifications';
        $this->load->view('admin/about/certification/add', $data);
    }
    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Certification_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 2;
            $data['sub_active'] = 22;
            $data['page_title'] = "Edit Certification";
            $edit_response = $this->Certification_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/certifications');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/certifications';
            $this->load->view('admin/about/certification/edit', $data);
        } else {
            redirect('admin/certifications');
        }
    }

    public function organize()
    {
        $this->Certification_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Certification_modal->view($id);
        if (!empty($detail)) {
            $this->Certification_modal->delete($id);
            $this->session->set_flashdata('msg', "Certification Deleted");
            redirect('admin/certifications');
        } else {
            redirect('admin/certifications');
        }
    }
}
