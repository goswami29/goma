<?php

class Tags extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Tags_modal');
    }

    public function index()
    {
        $data = $this->Tags_modal->index();
        $data['active_tab'] = 5;
        $data['sub_active'] = 105;
        $data['page_title'] = "Tag List";
        $data['redirect_url'] = 'admin/tags';
        $this->load->view('admin/blogs/tags/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 5;
        $data['sub_active'] = 105;
        $data['page_title'] = "Tag Form";
        $add_response = $this->Tags_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/tags');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/tags';
        $this->load->view('admin/blogs/tags/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Tags_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 5;
            $data['sub_active'] = 105;
            $data['page_title'] = "Edit Tag";
            $edit_response = $this->Tags_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/tags');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/tags';
            $this->load->view('admin/blogs/tags/edit', $data);
        } else {
            redirect('admin/tags');
        }
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Tags_modal->view($id);
        if (!empty($detail)) {
            $this->Tags_modal->delete($id);
            $this->session->set_flashdata('msg', "Tag Deleted");
            redirect('admin/tags');
        } else {
            redirect('admin/tags');
        }
    }
}
