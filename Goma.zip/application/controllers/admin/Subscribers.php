<?php

class Subscribers extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
    }

    public function index()
    {
        $data = array();
        $data['active_tab'] = 17;
        $data['sub_active'] = 171;
        $data['page_title'] = "Subscriber List";
        $data['list'] = $this->db->select('*')->get('subscribe')->result_array();
        $this->load->view('admin/pages/subscriberlist', $data);
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->db->select('id')->where('id', $id)->get('subscribe')->row_array();
        if (!empty($detail)) {
            $this->db->where('id', $id)->delete('subscribe');
            $this->session->set_flashdata('msg', "Record Deleted");
            redirect('admin/subscribers');
        } else {
            redirect('admin/subscribers');
        }
    }
}
