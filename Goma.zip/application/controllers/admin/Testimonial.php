<?php

class Testimonial extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Testimonial_modal');
    }

    public function index()
    {
        $data = $this->Testimonial_modal->index();
        $data['active_tab'] = 1;
        $data['sub_active'] = 12;
        $data['page_title'] = "Testimonials";
        $this->load->view('admin/testimonial/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 1;
        $data['sub_active'] = 12;
        $data['page_title'] = "Testimonial Form";
        $add_response = $this->Testimonial_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/testimonial');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/testimonial';
        $this->load->view('admin/testimonial/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Testimonial_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 1;
            $data['sub_active'] = 12;
            $data['page_title'] = "Edit Testimonial";
            $edit_response = $this->Testimonial_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/testimonial');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/testimonial';
            $this->load->view('admin/testimonial/edit', $data);
        } else {
            redirect('admin/testimonial');
        }
    }

    public function organize()
    {
        $this->Testimonial_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Testimonial_modal->view($id);
        if (!empty($detail)) {
            $this->Testimonial_modal->delete($id);
            $this->session->set_flashdata('msg', "Testimonial Deleted");
            redirect('admin/testimonial');
        } else {
            redirect('admin/testimonial');
        }
    }
}
