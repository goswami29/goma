<?php

class News extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('News_modal');
    }

    /******** News Seo Function ********/
    public function page()
    {
        $data = array();
        $data['active_tab'] = 8;
        $data['sub_active'] = 80;
        $data['page_title'] = "News Page";

        $detail = $this->News_modal->view_news_seo();
        $add_response = $this->News_modal->add_news_seo();

        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/news/page');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }

        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $this->load->view('admin/news/news_page', $data);
    }

    public function index()
    {
        $data = $this->News_modal->index();
        $data['active_tab'] = 8;
        $data['sub_active'] = 81;
        $data['page_title'] = "News List";
        $this->load->view('admin/news/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 8;
        $data['sub_active'] = 81;
        $data['page_title'] = "News Form";
        $add_response = $this->News_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/news');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/news';
        $this->load->view('admin/news/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->News_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 8;
            $data['sub_active'] = 81;
            $data['page_title'] = "Edit News";
            $edit_response = $this->News_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/news');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/news';
            $this->load->view('admin/news/edit', $data);
        } else {
            redirect('admin/news');
        }
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->News_modal->view($id);
        if (!empty($detail)) {
            $this->News_modal->delete($id);
            $this->session->set_flashdata('msg', "News Deleted");
            redirect('admin/news');
        } else {
            redirect('admin/news');
        }
    }
}
