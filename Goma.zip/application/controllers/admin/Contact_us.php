<?php

class contact_us extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Contactus_modal');
    }

    public function index()
    {
        $data = array();
        $data['active_tab'] = 4;
        $data['sub_active'] = 40;
        $data['page_title'] = "Contact Us";

        $detail = $this->Contactus_modal->view();
        $add_response = $this->Contactus_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/contact_us');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $this->load->view('admin/contact/contactus_form', $data);
    }

    public function enquiry()
    {
        $data = array();
        $data['active_tab'] = 4;
        $data['sub_active'] = 41;
        $data['page_title'] = "Contact Enquiry";
        $data['list'] = $this->Contactus_modal->enquiry_list();
        $this->load->view('admin/contact/contact_enquiry', $data);
    }

    public function contact_enquiry()
    {
        $add_response = $this->Contactus_modal->contact_enquiry();
        return json_encode($add_response);
    }

    public function delete_enquiry($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Contactus_modal->view_enquiry($id);
        if (!empty($detail)) {
            $this->Contactus_modal->delete_enquiry($id);
            $this->session->set_flashdata('msg', "Record Deleted");
            redirect('admin/contact_us/enquiry');
        } else {
            redirect('admin/contact_us/enquiry');
        }
    }

    public function view_enquiry($id)
    {
        $data = array();
        $data['active_tab'] = 4;
        $data['sub_active'] = 41;
        $data['page_title'] = "Contact Enquiry Details";
        $id = substr(safe_b64decode($id), 8);
        $data['show_data'] = $this->Contactus_modal->view_enquiry($id);
        $data['redirect_url'] = 'admin/contact_us/enquiry';
        $this->load->view('admin/contact/contact_enquiry_view', $data);
    }
}
