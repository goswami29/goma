<?php
class Clients extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Client_modal');
    }

    public function index()
    {
        $data = $this->Client_modal->index();
        $data['active_tab'] = 1;
        $data['sub_active'] = 11;
        $data['page_title'] = "Clients";
        $this->load->view('admin/clients/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 1;
        $data['sub_active'] = 11;
        $data['page_title'] = "Client Form";
        $add_response = $this->Client_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/clients');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/clients';
        $this->load->view('admin/clients/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Client_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 1;
            $data['sub_active'] = 11;
            $data['page_title'] = "Edit Client";
            $edit_response = $this->Client_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/clients');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/clients';
            $this->load->view('admin/clients/edit', $data);
        } else {
            redirect('admin/clients');
        }
    }

    public function organize()
    {
        $this->Client_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Client_modal->view($id);
        if (!empty($detail)) {
            $this->Client_modal->delete($id);
            $this->session->set_flashdata('msg', "Client Deleted");
            redirect('admin/clients');
        } else {
            redirect('admin/clients');
        }
    }
}
