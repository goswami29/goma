<?php

class Services extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Service_modal');
    }

    public function page()
    {
        $data = array();
        $data['active_tab'] = 3;
        $data['sub_active'] = 30;
        $data['page_title'] = "Service Page";

        $detail = $this->Service_modal->view_service_seo();
        $add_response = $this->Service_modal->add_service_seo();

        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/services/page');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $data['redirect_url'] = 'admin/services/page';
        $this->load->view('admin/service/service_page', $data);
    }

    /************ Service List Functions ***********/

    public function index()
    {
        $data = $this->Service_modal->index();
        $data['active_tab'] = 3;
        $data['sub_active'] = 31;
        $data['page_title'] = "Service List";
        $this->load->view('admin/service/index', $data);
    }
    public function add()
    {
        $data = array();
        $data['active_tab'] = 3;
        $data['sub_active'] = 31;
        $data['page_title'] = "Service Form";
        $add_response = $this->Service_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/services');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/services';
        $this->load->view('admin/service/add', $data);
    }
    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Service_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 3;
            $data['sub_active'] = 31;
            $data['page_title'] = "Edit Service";
            $edit_response = $this->Service_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/services');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/services';
            $this->load->view('admin/service/edit', $data);
        } else {
            redirect('admin/services');
        }
    }

    public function organize()
    {
        $this->Service_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Service_modal->view($id);
        if (!empty($detail)) {
            $this->Service_modal->delete($id);
            $this->session->set_flashdata('msg', "Service Deleted");
            redirect('admin/services');
        } else {
            redirect('admin/services');
        }
    }


    /*****************  Service Enquiry ******************/

    public function enquiry()
    {
        $data = array();
        $data['active_tab'] = 3;
        $data['sub_active'] = 32;
        $data['page_title'] = "Service Enquiry";
        $data['list'] = $this->Service_modal->enquiry_list();
        $this->load->view('admin/service/service_enquiry', $data);
    }

    public function delete_enquiry($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Service_modal->view_enquiry($id);
        if (!empty($detail)) {
            $this->Service_modal->delete_enquiry($id);
            $this->session->set_flashdata('msg', "Record Deleted");
            redirect('admin/services/enquiry');
        } else {
            redirect('admin/services/enquiry');
        }
    }

    public function view_enquiry($id)
    {
        $data = array();
        $data['active_tab'] = 3;
        $data['sub_active'] = 32;
        $data['page_title'] = "Service Enquiry Details";
        $id = substr(safe_b64decode($id), 8);
        $data['show_data'] = $this->Service_modal->view_enquiry($id);
        $data['redirect_url'] = 'admin/services/enquiry';
        $this->load->view('admin/service/service_enquiry_view', $data);
    }
}
