<?php

class Slider extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Slider_modal');
    }

    public function index()
    {
        $data = $this->Slider_modal->index();
        $data['active_tab'] = 1;
        $data['sub_active'] = 13;
        $data['page_title'] = "Slider List";
        $this->load->view('admin/slider/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 1;
        $data['sub_active'] = 13;
        $data['page_title'] = "Slider Form";
        $add_response = $this->Slider_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/slider');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/slider';
        $this->load->view('admin/slider/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Slider_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 1;
            $data['sub_active'] = 13;
            $data['page_title'] = "Edit Slider";
            $edit_response = $this->Slider_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/slider');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/slider';
            $this->load->view('admin/slider/edit', $data);
        } else {
            redirect('admin/slider');
        }
    }

    public function organize()
    {
        $this->Slider_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Slider_modal->view($id);
        if (!empty($detail)) {
            $this->Slider_modal->delete($id);
            $this->session->set_flashdata('msg', "Slider Deleted");
            redirect('admin/slider');
        } else {
            redirect('admin/slider');
        }
    }
}
