<?php
class Dynamic_content extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Pages_modal');
    }

    public function index()
    {
        $data['active_tab'] = 17;
        $data['sub_active'] = 171;
        $data = $this->Pages_modal->index();
        $data['page_title'] = "Dynamic Content List";
        $this->load->view('admin/dynamic_content', $data);
    }
}
