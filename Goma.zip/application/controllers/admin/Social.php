<?php

class Social extends CI_Controller
{

    public function __construct()
    {

        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Social_modal');
    }

    public function index()
    {
        $data = $this->Social_modal->index();
        $data['active_tab'] = 17;
        $data['sub_active'] = 105;
        $data['page_title'] = "Social Link";
        $data['redirect_url'] = 'admin/dynamic_content';
        $this->load->view('admin/social/index', $data);
    }
    public function add()
    {
        $data = array();
        $data['active_tab'] = 17;
        $data['sub_active'] = 105;
        $data['page_title'] = "Social Link Form";
        $add_response = $this->Social_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/social');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/social';
        $this->load->view('admin/social/add', $data);
    }
    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Social_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 17;
            $data['sub_active'] = 105;
            $data['page_title'] = "Edit Social Link";
            $edit_response = $this->Social_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/social');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/social';
            $this->load->view('admin/social/edit', $data);
        } else {
            redirect('admin/social');
        }
    }

    public function organize()
    {
        $this->Social_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Social_modal->view($id);
        if (!empty($detail)) {
            $this->Social_modal->delete($id);
            $this->session->set_flashdata('msg', "Social Link Deleted");
            redirect('admin/social');
        } else {
            redirect('admin/social');
        }
    }
}
