<?php
class Pressure_pumps extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Pressure_pumps_modal');
    }

    // High Pressure Pumps Page SEO Function
    public function index()
    {
        $data = array();
        $data['active_tab'] = 7;
        $data['sub_active'] = 70;
        $data['page_title'] = "High Pressure Pumps";

        $detail = $this->Pressure_pumps_modal->view_pressure_pumps_seo();
        $add_response = $this->Pressure_pumps_modal->add_pressure_pumps_seo();

        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/pressure_pumps');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }

        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $this->load->view('admin/pressure_pumps/pressure_pumps_page', $data);
    }


    /***************** Industry Functions ****************/

    public function industry()
    {
        $data = $this->Pressure_pumps_modal->index();
        $data['active_tab'] = 7;
        $data['sub_active'] = 71;
        $data['page_title'] = "High Pressure Pumps Industry List";
        $this->load->view('admin/pressure_pumps/industry/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 7;
        $data['sub_active'] = 71;
        $data['page_title'] = "Industry Form";
        $add_response = $this->Pressure_pumps_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/pressure_pumps/industry');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/pressure_pumps/industry';
        $this->load->view('admin/pressure_pumps/industry/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Pressure_pumps_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 7;
            $data['sub_active'] = 71;
            $data['page_title'] = "Edit Industry";
            $edit_response = $this->Pressure_pumps_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/pressure_pumps/industry');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/pressure_pumps/industry';
            $this->load->view('admin/pressure_pumps/industry/edit', $data);
        } else {
            redirect('admin/pressure_pumps');
        }
    }

    public function organize()
    {
        $this->Pressure_pumps_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Pressure_pumps_modal->view($id);
        if (!empty($detail)) {
            $this->Pressure_pumps_modal->delete($id);
            $this->session->set_flashdata('msg', "Industry Deleted");
            redirect('admin/pressure_pumps/industry');
        } else {
            redirect('admin/pressure_pumps/industry');
        }
    }

    /*********************** Pressure Pump Category Functions ************************/

    public function category()
    {
        $data = $this->Pressure_pumps_modal->index_category();
        $data['active_tab'] = 7;
        $data['sub_active'] = 72;
        $data['page_title'] = "Category List";
        $this->load->view('admin/pressure_pumps/category/index', $data);
    }

    public function add_category()
    {
        $data = array();
        $data['active_tab'] = 7;
        $data['sub_active'] = 72;
        $data['page_title'] = "Category Form";
        $add_response = $this->Pressure_pumps_modal->add_category();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/pressure_pumps/category');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/pressure_pumps/category';
        $this->load->view('admin/pressure_pumps/category/add', $data);
    }

    public function edit_category($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Pressure_pumps_modal->view_category($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 7;
            $data['sub_active'] = 72;
            $data['page_title'] = "Edit Category";
            $edit_response = $this->Pressure_pumps_modal->edit_category($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/pressure_pumps/category');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/pressure_pumps/category';
            $this->load->view('admin/pressure_pumps/category/edit', $data);
        } else {
            redirect('admin/pressure_pumps/category');
        }
    }

    public function delete_category($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Pressure_pumps_modal->view_category($id);
        if (!empty($detail)) {
            $this->Pressure_pumps_modal->delete_category($id);
            $this->session->set_flashdata('msg', "Category Deleted");
            redirect('admin/pressure_pumps/category');
        } else {
            redirect('admin/pressure_pumps/category');
        }
    }

    /***************** Events Functions ****************/

    public function events()
    {
        $data = $this->Pressure_pumps_modal->events();
        $data['active_tab'] = 7;
        $data['sub_active'] = 74;
        $data['page_title'] = "High Pressure Pumps Events";
        $this->load->view('admin/pressure_pumps/events/index', $data);
    }

    public function add_event()
    {
        $data = array();
        $data['active_tab'] = 7;
        $data['sub_active'] = 74;
        $data['page_title'] = "High Pressure Pumps Event Form";
        $add_response = $this->Pressure_pumps_modal->add_event();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/pressure_pumps/events');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/pressure_pumps/events';
        $this->load->view('admin/pressure_pumps/events/add', $data);
    }

    public function edit_event($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Pressure_pumps_modal->view_event($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 7;
            $data['sub_active'] = 74;
            $data['page_title'] = "High Pressure Pumps Edit Industry";
            $edit_response = $this->Pressure_pumps_modal->edit_event($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/pressure_pumps/events');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/pressure_pumps/events';
            $this->load->view('admin/pressure_pumps/events/edit', $data);
        } else {
            redirect('admin/pressure_pumps/events');
        }
    }

    public function delete_event($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Pressure_pumps_modal->view_event($id);
        if (!empty($detail)) {
            $this->Pressure_pumps_modal->delete_event($id);
            $this->session->set_flashdata('msg', "Event Deleted");
            redirect('admin/pressure_pumps/events');
        } else {
            redirect('admin/pressure_pumps/events');
        }
    }

    public function organize_event()
    {
        $this->Pressure_pumps_modal->organize_event();
    }

    function upload_event_images()
    {
        if (isset($_FILES) && !empty($_FILES)) {
            $cnt = count($_FILES);
            $_FILES['event_image_file'] = array();
            for ($i = 0; $i < $cnt; $i++) {
                $_FILES['event_image_file']['name'][$i] = $_FILES[$i]['name'];
                $_FILES['event_image_file']['type'][$i] = $_FILES[$i]['type'];
                $_FILES['event_image_file']['tmp_name'][$i] = $_FILES[$i]['tmp_name'];
                $_FILES['event_image_file']['error'][$i] = $_FILES[$i]['error'];
                $_FILES['event_image_file']['size'][$i] = $_FILES[$i]['size'];
            }
        }
        $path = 'uploads/pressure_pumps/events';
        $files = $_FILES['event_image_file'];
        $title = "";
        $images = array();
        $images = $this->upload_files_to_folder($path, $title, $files);
        echo json_encode($images);
    }

    function upload_files_to_folder($path, $title, $files)
    {
        $return = array();
        $config = array(
            'upload_path' => $path,
            'allowed_types' => '*',
            'overwrite' => 1,
            'remove_spaces' => TRUE,
            'encrypt_name' => TRUE
        );

        $this->load->library('upload', $config);
        $images = array();
        $msg = array();
        foreach ($files['name'] as $key => $image) {
            $_FILES['images[]']['name'] = $files['name'][$key];
            $_FILES['images[]']['type'] = $files['type'][$key];
            $_FILES['images[]']['tmp_name'] = $files['tmp_name'][$key];
            $_FILES['images[]']['error'] = $files['error'][$key];
            $_FILES['images[]']['size'] = $files['size'][$key];

            $fileName = time() . '_' . str_replace(' ', '_', $image);
            $config['file_name'] = $fileName;
            $this->upload->initialize($config);
            if ($this->upload->do_upload('images[]')) {
                $file_info = $this->upload->data();
                $images[] = $file_info['file_name'];
                $status = 1;
            } else {
                $status = 0;
                $msg[] = $this->upload->display_errors();
            }
        }
        $return['status'] = $status;
        $return['msg'] = $msg;
        $return['image'] = $images;
        return $return;
    }
}
