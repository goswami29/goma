<?php

class Pages extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Pages_modal');
    }

    // public function index()
    // {
    //     $data = $this->Pages_modal->index();
    //     $data['active_tab'] = 10;
    //     $data['sub_active'] = 103;
    //     $data['page_title'] = "Pages List";
    //     $this->load->view('admin/pages/list', $data);
    // }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 17;
        $data['sub_active'] = 171;
        $data['page_title'] = "Pages";
        $add_response = $this->Pages_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/dynamic_content');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/dynamic_content';
        $this->load->view('admin/pages/add', $data);
    }
    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Pages_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 17;
            $data['sub_active'] = 171;
            $data['page_title'] = "Pages";
            $edit_response = $this->Pages_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/dynamic_content');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/dynamic_content';
            $this->load->view('admin/pages/edit', $data);
        } else {
            redirect('admin/dynamic_content');
        }
    }

    // public function delete($id)
    // {
    //     $id = substr(safe_b64decode($id), 8);
    //     $detail = $this->Pages_modal->view($id);
    //     if (!empty($detail)) {
    //         $this->Pages_modal->delete($id);
    //         $this->session->set_flashdata('msg', "Pages Deleted");
    //         redirect('admin/pages');
    //     } else {
    //         redirect('admin/pages');
    //     }
    // }
}
