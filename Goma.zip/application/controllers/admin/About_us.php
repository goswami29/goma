<?php

class About_us extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Aboutus_modal');
    }

    public function index()
    {
        $data = array();
        $data['active_tab'] = 2;
        $data['sub_active'] = 20;
        $data['page_title'] = "About Us";

        $detail = $this->Aboutus_modal->view();
        $add_response = $this->Aboutus_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/about_us');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $this->load->view('admin/about/aboutus_form', $data);
    }
}
