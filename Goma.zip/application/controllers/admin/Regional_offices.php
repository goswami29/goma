<?php

class Regional_offices extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Regional_offices_modal');
    }

    public function index()
    {
        $data = $this->Regional_offices_modal->index();
        $data['active_tab'] = 4;
        $data['sub_active'] = 42;
        $data['page_title'] = "Regional Offices";
        $this->load->view('admin/contact/regional_offices/index', $data);
    }
    public function add()
    {
        $data = array();
        $data['active_tab'] = 4;
        $data['sub_active'] = 42;
        $data['page_title'] = "Regional Office Form";
        $add_response = $this->Regional_offices_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/regional_offices');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/regional_offices';
        $this->load->view('admin/contact/regional_offices/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Regional_offices_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 4;
            $data['sub_active'] = 42;
            $data['page_title'] = "Edit Regional Office";
            $edit_response = $this->Regional_offices_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/regional_offices');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/regional_offices';
            $this->load->view('admin/contact/regional_offices/edit', $data);
        } else {
            redirect('admin/regional_offices');
        }
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Regional_offices_modal->view($id);
        if (!empty($detail)) {
            $this->Regional_offices_modal->delete($id);
            $this->session->set_flashdata('msg', "Office Deleted");
            redirect('admin/regional_offices');
        } else {
            redirect('admin/regional_offices');
        }
    }
}
