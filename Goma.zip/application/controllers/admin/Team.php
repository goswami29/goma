<?php

class Team extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Team_modal');
    }

    public function index()
    {
        $data = $this->Team_modal->index();
        $data['active_tab'] = 2;
        $data['sub_active'] = 21;
        $data['page_title'] = "About Team List";
        $this->load->view('admin/about/team/index', $data);
    }
    public function add()
    {
        $data = array();
        $data['active_tab'] = 2;
        $data['sub_active'] = 21;
        $data['page_title'] = "Team Form";
        $add_response = $this->Team_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/team');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/team';
        $this->load->view('admin/about/team/add', $data);
    }
    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Team_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 2;
            $data['sub_active'] = 21;
            $data['page_title'] = "Edit Team";
            $edit_response = $this->Team_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/team');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/team';
            $this->load->view('admin/about/team/edit', $data);
        } else {
            redirect('admin/team');
        }
    }

    public function organize()
    {
        $this->Team_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Team_modal->view($id);
        if (!empty($detail)) {
            $this->Team_modal->delete($id);
            $this->session->set_flashdata('msg', "Team Deleted");
            redirect('admin/team');
        } else {
            redirect('admin/team');
        }
    }
}
