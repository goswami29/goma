<?php
class Process_technology extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->admin = admin_login_data();
        if (empty($this->admin)) {
            redirect('admin/login');
        }
        $this->load->model('Process_technology_modal');
    }

    // Process Technology Page SEO Function
    public function index()
    {
        $data = array();
        $data['active_tab'] = 6;
        $data['sub_active'] = 60;
        $data['page_title'] = "Process Technology";

        $detail = $this->Process_technology_modal->view_process_technology_seo();
        $add_response = $this->Process_technology_modal->add_process_technology_seo();

        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/process_technology');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }

        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
        $this->load->view('admin/process_technology/process_technology_page', $data);
    }


    /***************** Industry Functions ****************/

    public function industry()
    {
        $data = $this->Process_technology_modal->index();
        $data['active_tab'] = 6;
        $data['sub_active'] = 61;
        $data['page_title'] = "Industry List";
        $this->load->view('admin/process_technology/industry/index', $data);
    }

    public function add()
    {
        $data = array();
        $data['active_tab'] = 6;
        $data['sub_active'] = 61;
        $data['page_title'] = "Industry Form";
        $add_response = $this->Process_technology_modal->add();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/process_technology/industry');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/process_technology/industry';
        $this->load->view('admin/process_technology/industry/add', $data);
    }

    public function edit($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Process_technology_modal->view($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 6;
            $data['sub_active'] = 61;
            $data['page_title'] = "Edit Industry";
            $edit_response = $this->Process_technology_modal->edit($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/process_technology/industry');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/process_technology/industry';
            $this->load->view('admin/process_technology/industry/edit', $data);
        } else {
            redirect('admin/process_technology');
        }
    }

    public function organize()
    {
        $this->Process_technology_modal->organize();
    }

    public function delete($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Process_technology_modal->view($id);
        if (!empty($detail)) {
            $this->Process_technology_modal->delete($id);
            $this->session->set_flashdata('msg', "Industry Deleted");
            redirect('admin/process_technology/industry');
        } else {
            redirect('admin/process_technology/industry');
        }
    }

    /***************** Events Functions ****************/

    public function events()
    {
        $data = $this->Process_technology_modal->events();
        $data['active_tab'] = 6;
        $data['sub_active'] = 64;
        $data['page_title'] = "Process Technology Events";
        $this->load->view('admin/process_technology/events/index', $data);
    }

    public function add_event()
    {
        $data = array();
        $data['active_tab'] = 6;
        $data['sub_active'] = 64;
        $data['page_title'] = "Process Technology Event Form";
        $add_response = $this->Process_technology_modal->add_event();
        if ($add_response['status'] == 1) {
            $this->session->set_flashdata('msg', $add_response['msg']);
            redirect('admin/process_technology/events');
            exit();
        } else {
            $data['error'] = $add_response['msg'];
        }
        $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : array());
        $data['redirect_url'] = 'admin/process_technology/events';
        $this->load->view('admin/process_technology/events/add', $data);
    }

    public function edit_event($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Process_technology_modal->view_event($id);
        if (!empty($detail)) {
            $data = array();
            $data['active_tab'] = 6;
            $data['sub_active'] = 64;
            $data['page_title'] = "Process Technology Edit Industry";
            $edit_response = $this->Process_technology_modal->edit_event($id);
            if ($edit_response['status'] == 1) {
                $this->session->set_flashdata('msg', $edit_response['msg']);
                redirect('admin/process_technology/events');
                exit();
            } else {
                $data['error'] = $edit_response['msg'];
            }
            $data['show_data'] = (isset($_POST) && !empty($_POST) ? $_POST : $detail);
            $data['redirect_url'] = 'admin/process_technology/events';
            $this->load->view('admin/process_technology/events/edit', $data);
        } else {
            redirect('admin/process_technology/events');
        }
    }

    public function delete_event($id)
    {
        $id = substr(safe_b64decode($id), 8);
        $detail = $this->Process_technology_modal->view_event($id);
        if (!empty($detail)) {
            $this->Process_technology_modal->delete_event($id);
            $this->session->set_flashdata('msg', "Event Deleted");
            redirect('admin/process_technology/events');
        } else {
            redirect('admin/process_technology/events');
        }
    }

    public function organize_event()
    {
        $this->Process_technology_modal->organize_event();
    }

    function upload_event_images()
    {
        if (isset($_FILES) && !empty($_FILES)) {
            $cnt = count($_FILES);
            $_FILES['event_image_file'] = array();
            for ($i = 0; $i < $cnt; $i++) {
                $_FILES['event_image_file']['name'][$i] = $_FILES[$i]['name'];
                $_FILES['event_image_file']['type'][$i] = $_FILES[$i]['type'];
                $_FILES['event_image_file']['tmp_name'][$i] = $_FILES[$i]['tmp_name'];
                $_FILES['event_image_file']['error'][$i] = $_FILES[$i]['error'];
                $_FILES['event_image_file']['size'][$i] = $_FILES[$i]['size'];
            }
        }
        $path = 'uploads/process_technology/events';
        $files = $_FILES['event_image_file'];
        $title = "";
        $images = array();
        $images = $this->upload_files_to_folder($path, $title, $files);
        echo json_encode($images);
    }

    function upload_files_to_folder($path, $title, $files)
    {
        $return = array();
        $config = array(
            'upload_path' => $path,
            'allowed_types' => '*',
            'overwrite' => 1,
            'remove_spaces' => TRUE,
            'encrypt_name' => TRUE
        );

        $this->load->library('upload', $config);
        $images = array();
        $msg = array();
        foreach ($files['name'] as $key => $image) {
            $_FILES['images[]']['name'] = $files['name'][$key];
            $_FILES['images[]']['type'] = $files['type'][$key];
            $_FILES['images[]']['tmp_name'] = $files['tmp_name'][$key];
            $_FILES['images[]']['error'] = $files['error'][$key];
            $_FILES['images[]']['size'] = $files['size'][$key];

            $fileName = time() . '_' . str_replace(' ', '_', $image);
            $config['file_name'] = $fileName;
            $this->upload->initialize($config);
            if ($this->upload->do_upload('images[]')) {
                $file_info = $this->upload->data();
                $images[] = $file_info['file_name'];
                $status = 1;
            } else {
                $status = 0;
                $msg[] = $this->upload->display_errors();
            }
        }
        $return['status'] = $status;
        $return['msg'] = $msg;
        $return['image'] = $images;
        return $return;
    }
}
