<?php

function generateKey($length = 8, $use_upper = 1, $use_lower = 1, $use_number = 1, $use_custom = "")
{
    $CI = get_instance();
    $upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $lower = "abcdefghijklmnopqrstuvwxyz";
    $number = "0123456789";
    $password = "";
    $seed = "";
    $seed_length = 0;
    if ($use_upper) {
        $seed_length += 26;
        $seed .= $upper;
    }
    if ($use_lower) {
        $seed_length += 26;
        $seed .= $lower;
    }
    if ($use_number) {
        $seed_length += 10;
        $seed .= $number;
    }
    if ($use_custom) {
        $seed_length += strlen($use_custom);
        $seed .= $use_custom;
    }
    for ($x = 1; $x <= $length; $x++) {
        $password .= $seed[rand(0, $seed_length - 1)];
    }
    return $password;
}

function check_generate_key($regKey, $table, $table_column)
{
    $CI = get_instance();
    $arr = $CI->db->select($table_column)->where($table_column, $regKey)->get($table)->row_array();
    $output = array();
    if (!empty($arr)) {
        $output = $arr;
    }
    return $output;
}

function generate_string_key($length, $table, $table_column)
{
    $CI = get_instance();
    $loop = 1;
    do {
        $regKey = generateKey($length);
        $regKey = ltrim($regKey);
        if (strlen($regKey) != $length || substr($regKey, 0, 1) == "0" || substr($regKey, 0, 1) == 0) {
            continue;
        }
        $arr = check_generate_key($regKey, $table, $table_column);
        if (empty($arr)) {
            $loop = 0;
        }
    } while ($loop == 1);
    return $regKey;
}

function generate_number_key($length, $table, $table_column)
{
    $CI = get_instance();
    $loop = 1;
    do {
        $regKey = generateKey($length, 0, 0, 1);
        $regKey = ltrim($regKey);
        if (strlen($regKey) != $length || substr($regKey, 0, 1) == "0" || substr($regKey, 0, 1) == 0) {
            continue;
        }
        $arr = check_generate_key($regKey, $table, $table_column);
        if (empty($arr)) {
            $loop = 0;
        }
    } while ($loop == 1);
    return $regKey;
}

function safe_b64encode($string)
{
    $data = base64_encode($string);
    $data = str_replace(array('+', '/', '='), array('-', '_', ''), $data);
    return $data;
}

function safe_b64decode($string)
{
    $data = str_replace(array('-', '_'), array('+', '/'), $string);
    $mod4 = strlen($data) % 4;
    if ($mod4) {
        $data .= substr('====', $mod4);
    }
    return base64_decode($data);
}

function get_client_ip()
{
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if (isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if (isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if (isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if (isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';

    return $ipaddress;
}

function email_send($to = '', $sub = '', $msg = '', $cc = array(), $bcc = array(), $attach = '')
{
    $CI = get_instance();
    $CI->load->library('email');
    $from = 'no-reply@icsemaths.in';

    $config = array();
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'mail.icsemaths.in';
    $config['smtp_port'] = '587';
    $config['smtp_user'] = 'no-reply@icsemaths.in';
    $config['smtp_pass'] = 'ICSE@math';
    $config['charset'] = 'utf-8';
    $config['newline'] = "\r\n";
    $config['mailtype'] = 'html'; // text or html
    $config['validation'] = TRUE; // bool whether to validate email or not

    $CI->email->initialize($config);
    $CI->email->from($from, APP_NAME);
    $CI->email->to($to);
    $CI->email->subject($sub);
    $CI->email->message($msg);
    if (!empty($attach)) {
        $CI->email->attach($attach);
    }
    if (!empty($cc)) {
        $CI->email->cc($cc);
    }
    $bcc = array('rahul.digiinterface@gmail.com');
    if (!empty($bcc)) {
        $CI->email->bcc($bcc);
    }
    $CI->email->send();
    // echo $CI->email->print_debugger();
    // exit();
    $CI->email->clear(TRUE);
    return true;
}

// function send_sms($contacts, $msg_data, $msg_for)
// {
//     $CI = get_instance();
//     $sms_data = $CI->db->where('status', 1)->where('sms_for', $msg_for)->get('sms_template')->row_array();
//     if (!empty($sms_data)) {
//         $message_content = $sms_data['message_content'];
//         if (!empty($msg_data)) {
//             $msg_data_check = array();
//             foreach ($msg_data as $key => $val) {
//                 $msg_data_check[sprintf('[%s]', $key)] = $val;
//             }
//             $message_content = strtr($message_content, $msg_data_check);
//         }

//         $key = "460BF5584B82E8";
//         $senderid = "ICSEMT";
//         $number = '91' . $contacts;
//         $template_id = $sms_data['template_id'];
//         $message = urlencode($message_content);
//         $url_keys = "key=" . $key . "&campaign=1863&routeid=1&type=text&contacts=" . $number . "&senderid=" . $senderid . "&template=" . $template_id . "&msg=" . $message;
//         // echo '<br><br>'.$url_keys."<br><br>";

//         $ch = curl_init();
//         curl_setopt($ch, CURLOPT_URL, "https://mysms.goyalinfotech.com/smsapi/index");
//         curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//         curl_setopt($ch, CURLOPT_HEADER, false);
//         curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
//         curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
//         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
//         curl_setopt($ch, CURLOPT_POST, 1);
//         curl_setopt($ch, CURLOPT_POSTFIELDS, $url_keys);
//         $response = curl_exec($ch);
//         // echo '<br><br>Curl error: ' . curl_error($ch)."<br><br>";
//         curl_close($ch);
//         $response = json_decode($response, TRUE);
//         echo "<pre>";
//         print_r($response);
//         exit();
//         return json_decode($response, TRUE);
//     } else {
//         return array("result" => "error", "sms_shoot_id" => "0", "message" => "Template not specified-no msg for");
//     }
// }

function pagination($total, $per_page = 10, $page = 1, $url = '?')
{
    $adjacents = "2";
    $page = ($page == 0 ? 1 : $page);
    $start = ($page - 1) * $per_page;
    $prev = $page - 1;
    $next = $page + 1;
    @$lastpage = ceil($total / $per_page);
    $lpm1 = $lastpage - 1;
    $pagination = '';
    if ($lastpage > 1) {
        $pagination .= '<div class="row mt-3">
        <div class="col-lg-11 col-md-11 col-sm-10">';
        $pagination .= "<ul class='pagination'>";
        if ($lastpage < 7 + ($adjacents * 2)) {
            for ($counter = 1; $counter <= $lastpage; $counter++) {
                if ($counter == $page)
                    $pagination .= "<li><a class='btn btn-primary current text-white'>$counter</a></li>";
                else
                    $pagination .= "<li><a class='btn btn-default' href='{$url}page=$counter'>$counter</a></li>";
            }
        } elseif ($lastpage > 5 + ($adjacents * 2)) {
            if ($page < 1 + ($adjacents * 2)) {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li><a class='btn btn-primary'>$counter</a></li>";
                    else
                        $pagination .= "<li><a class='btn btn-default' href='{$url}page=$counter'>$counter</a></li>";
                }
                $pagination .= "<li class='dot'>...</li>";
                $pagination .= "<li><a class='btn btn-default' href='{$url}page=$lpm1'>$lpm1</a></li>";
                $pagination .= "<li><a class='btn btn-default' href='{$url}page=$lastpage'>$lastpage</a></li>";
            } elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                $pagination .= "<li><a class='btn btn-default' href='{$url}page=1'>1</a></li>";
                $pagination .= "<li><a class='btn btn-default' href='{$url}page=2'>2</a></li>";
                $pagination .= "<li class='dot'>...</li>";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li><a class='btn btn-primary current text-white'>$counter</a></li>";
                    else
                        $pagination .= "<li><a class='btn btn-default' href='{$url}page=$counter'>$counter</a></li>";
                }
                $pagination .= "<li class='dot'>..</li>";
                $pagination .= "<li><a class='btn btn-default' href='{$url}page=$lpm1'>$lpm1</a></li>";
                $pagination .= "<li><a class='btn btn-default' href='{$url}page=$lastpage'>$lastpage</a></li>";
            } else {
                $pagination .= "<li><a class='btn btn-default' href='{$url}page=1'>1</a></li>";
                $pagination .= "<li><a class='btn btn-default' href='{$url}page=2'>2</a></li>";
                $pagination .= "<li class='dot'>..</li>";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li><a class='btn btn-primary current text-white'>$counter</a></li>";
                    else
                        $pagination .= "<li><a class='btn btn-default' href='{$url}page=$counter'>$counter</a></li>";
                }
            }
        }
        if ($page < $counter - 1) {
            $pagination .= "<li><a class='btn btn-deafult' href='{$url}page=$next'>Next</a></li>";
            $pagination .= "<li><a class='btn btn-deafult' href='{$url}page=$lastpage'>Last</a></li>";
        } else {
            $pagination .= "<li><a class='btn btn-inverse current'>Next</a></li>";
            $pagination .= "<li><a class='btn btn-inverse current'>Last</a></li>";
        }
        $pagination .= "</ul>";
        $pagination .= '</div>
        <div class="col-lg-1 col-md-1 col-sm-2">
        <form action="" method="get">
        <select name="per_page" id="per_page" class="form-control input-sm" style="width: 80px; float: right;" onchange="this.form.submit();">
        <option value="5" ' . ($per_page == '5' ? 'selected' : '') . '>5</option>
        <option value="10" ' . ($per_page == '10' ? 'selected' : '') . '>10</option>
        <option value="20" ' . ($per_page == '20' ? 'selected' : '') . '>20</option>
        <option value="50" ' . ($per_page == '50' ? 'selected' : '') . '>50</option>
        <option value="100" ' . ($per_page == '100' ? 'selected' : '') . '>100</option>
        <option value="All" ' . ($per_page == 'All' ? 'selected' : '') . '>All</option>
        </select>
        </form>
        </div>
        </div>';
    }
    return $pagination;
}

function web_profile_pagination($total, $per_page = 10, $page = 1, $url = '?')
{
    $adjacents = "2";
    $page = ($page == 0 ? 1 : $page);
    $start = ($page - 1) * $per_page;
    $prev = $page - 1;
    $next = $page + 1;
    @$lastpage = ceil($total / $per_page);
    $lpm1 = $lastpage - 1;
    $pagination = '';
    if ($lastpage > 1) {
        $pagination .= '<div class="pagination-container"><nav>';
        $pagination .= "<ul class='pagination'>";
        if ($page > 1) {
            $pagination .= "<li class='page-item'><a class='btn btn-common' href='{$url}page=$prev'><i class='lni-chevron-left'></i> Previous </a></a></li>";
        } else {
            $pagination .= "<li class='page-item'><a class='btn btn-common current'><i class='lni-chevron-left'></i> Previous </a></li>";
        }
        if ($lastpage < 7 + ($adjacents * 2)) {
            for ($counter = 1; $counter <= $lastpage; $counter++) {
                if ($counter == $page)
                    $pagination .= "<li class='page-item'><a class='page-link current'>$counter</a></li>";
                else
                    $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$counter'>$counter</a></li>";
            }
        } elseif ($lastpage > 5 + ($adjacents * 2)) {
            if ($page < 1 + ($adjacents * 2)) {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li class='page-item'><a class='page-link'>$counter</a></li>";
                    else
                        $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$counter'>$counter</a></li>";
                }
                $pagination .= "<li  class='page-item dot'>...</li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$lpm1'>$lpm1</a></li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$lastpage'>$lastpage</a></li>";
            } elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=1'>1</a></li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=2'>2</a></li>";
                $pagination .= "<li  class='page-item dot'>...</li>";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li class='page-item'><a class='page-link current'>$counter</a></li>";
                    else
                        $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$counter'>$counter</a></li>";
                }
                $pagination .= "<li class='page-item dot'>..</li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$lpm1'>$lpm1</a></li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$lastpage'>$lastpage</a></li>";
            } else {
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=1'>1</a></li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=2'>2</a></li>";
                $pagination .= "<li class='page-item dot'>..</li>";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li class='page-item'><a class='page-link current'>$counter</a></li>";
                    else
                        $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$counter'>$counter</a></li>";
                }
            }
        }
        if ($page < $counter - 1) {
            $pagination .= "<li class='page-item'><a class='btn btn-common' href='{$url}page=$next'>Next <i class='lni-chevron-right'></i></a></li>";
        } else {
            $pagination .= "<li class='page-item'><a class='btn btn-common current'>Next <i class='lni-chevron-right'></i></a></li>";
        }
        $pagination .= "</ul>";
        $pagination .= '</nav></div>';
    }
    return $pagination;
}

function admin_login_data()
{
    $CI = get_instance();
    $admin_token = $CI->session->userdata('admin_login_token');
    return $CI->db->select('id,name,email')->where('id', $admin_token['id'])->get('users')->row_array();
}

function user_login_data()
{
    $CI = get_instance();
    $user_token = $CI->session->userdata('user_login_token');
    if (!empty($user_token)) {
        return $CI->db->select('id,user_type,name,email,mobile,profile_image,package_id')->where('login_token', $user_token)->get('users')->row_array();
    } else {
        return array();
    }
}

function get_login_data()
{
    $CI = get_instance();
    $admin_token = $CI->session->userdata('admin_login_token');
    $CI = get_instance();
    $qurey = "SELECT id,name,email FROM users WHERE id = " . "'" . $admin_token['id'] . "'";
    $result = $CI->db->query($qurey)->row_array();
    return $result;
}

function make_folder($path)
{
    if (!is_dir($path)) {
        mkdir($path, 0777, TRUE);
    }
}

function delete_upload_image($upload_path, $image_name)
{
    if (file_exists("./" . $upload_path . $image_name)) {
        unlink("./" . $upload_path . $image_name);
    }
}

function upload_image($upload_file_field_name, $upload_path, $last_uploaded_image_name = "")
{
    $CI = get_instance();
    $image_data = array();
    make_folder($upload_path);
    if (isset($_FILES[$upload_file_field_name]['name']) && !empty($_FILES[$upload_file_field_name]['name'])) {
        $config = array();
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg|svg';
        $config['max_size'] = 1000;
        $config['encrypt_name'] = TRUE;
        $config['remove_spaces'] = TRUE;
        $CI->load->library('upload');
        $CI->upload->initialize($config);
        if (!$CI->upload->do_upload($upload_file_field_name)) {
            $image_data['error'] = strip_tags($CI->upload->display_errors());
        } else {
            if (isset($last_uploaded_image_name) && !empty($last_uploaded_image_name)) {
                delete_upload_image($upload_path, $last_uploaded_image_name);
            }
            $image_data = $CI->upload->data();
            $image_data['name'] = $image_data['file_name'];
        }
    }
    return $image_data;
}

// PDF File Upload
function upload_pdf($upload_file_field_name, $upload_path, $last_uploaded_image_name = "")
{
    $CI = get_instance();
    $image_data = array();
    make_folder($upload_path);
    if (isset($_FILES[$upload_file_field_name]['name']) && !empty($_FILES[$upload_file_field_name]['name'])) {
        $config = array();
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'pdf|PDF|xlsx|xls|doc';
        //$config['max_size'] = 1000;
        $config['encrypt_name'] = TRUE;
        $config['remove_spaces'] = TRUE;
        $CI->load->library('upload');
        $CI->upload->initialize($config);
        if (!$CI->upload->do_upload($upload_file_field_name)) {
            $image_data['error'] = strip_tags($CI->upload->display_errors());
        } else {
            if (isset($last_uploaded_image_name) && !empty($last_uploaded_image_name)) {
                delete_upload_image($upload_path, $last_uploaded_image_name);
            }
            $image_data = $CI->upload->data();
            $image_data['name'] = $image_data['file_name'];
        }
    }
    return $image_data;
}

function resize_image($width, $height, $file_name, $source_path, $new_path = "")
{
    $CI = get_instance();
    $CI->load->library('image_lib');
    $config = array();
    $config['image_library'] = 'gd2';
    $config['source_image'] = $source_path . $file_name;
    if (!empty($new_path)) {
        make_folder($new_path);
        $config['new_image'] = $new_path . $file_name;
    }
    $config['maintain_ratio'] = TRUE;
    $config['width'] = $width;
    $config['height'] = $height;
    $CI->image_lib->initialize($config);
    $CI->image_lib->resize();
    $CI->image_lib->clear();
}

function clean_string($string, $replace_char = "")
{
    $string = strtolower(trim($string));
    $string = preg_replace('/[^A-Za-z0-9\ -_]/', '', $string); // Removes special chars.
    //        $string = preg_replace('/\\s+/', '', $string); // remove white spaces
    if (!empty($replace_char)) {
        $string = str_replace(' ', $replace_char, $string); // Replaces all spaces with hyphens.
        $string = preg_replace('/' . $replace_char . '+/', $replace_char, $string); // Replaces multiple hyphens with single one.
    }
    return $string;
}

function mask_detail($type, $data, $length = 4)
{
    if ($type == "phone") {
        return '*****' . substr($data, -$length);
    } else if ($type == "email") {
        return substr($data, 0, $length) . '***' . substr($data, strpos($data, "@"));
    }
}

function app_currency_amount($amount)
{
    return APP_CURRENCY . " " . number_format($amount);
}

function time_elapsed_string($ptime)
{
    $etime = time() - $ptime;

    if ($etime < 1) {
        return '0 seconds';
    }

    $a = array(
        365 * 24 * 60 * 60 => 'year',
        30 * 24 * 60 * 60 => 'month',
        24 * 60 * 60 => 'day',
        60 * 60 => 'hour',
        60 => 'minute',
        1 => 'second'
    );
    $a_plural = array(
        'year' => 'years',
        'month' => 'months',
        'day' => 'days',
        'hour' => 'hours',
        'minute' => 'minutes',
        'second' => 'seconds'
    );

    foreach ($a as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' ago';
        }
    }
}

function tokenTruncate($string, $your_desired_width)
{
    $parts = preg_split('/([\s\n\r]+)/u', $string, 'null', PREG_SPLIT_DELIM_CAPTURE);
    $parts_count = count($parts);

    $length = 0;
    $last_part = 0;
    for (; $last_part < $parts_count; ++$last_part) {
        $length += strlen($parts[$last_part]);
        if ($length > $your_desired_width) {
            break;
        }
    }

    return implode(array_slice($parts, 0, $last_part));
}

// Function to remove the spacial  
function removeSpecialChar($str)
{
    $res = str_ireplace(array('\'', '"', ',', '-', ';', '<', '>'), ' ', $str);
    return $res;
}

function get_data_where($table, $where, $group_by = '', $order_by = '', $limit = '', $select = '')
{
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->get_data_where($table, $where, $group_by, $order_by, $limit, $select);
}

function get_data_like($table, $where, $group_by = '', $order_by = '', $limit = '', $select = '')
{
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->get_data_like($table, $where, $group_by, $order_by, $limit, $select);
}

function delete_data_where($table, $where)
{
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->delete_data_where($table, $where);
}

function get_data_where_join($table, $where, $join_table, $Join_coloumn, $join_type = '', $select = '')
{
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->get_data_where_join($table, $where, $join_table, $Join_coloumn, $join_type, $select);
}

function add_data($data, $table)
{
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->add_data($data, $table);
}

function update_data($data, $where, $table)
{
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->update_data($data, $where, $table);
}

function currentTime()
{
    return strtotime(date('d-M-Y g:i:s A'));
}

function todaysTime()
{
    return strtotime(date('d-M-Y'));
}

function currentDate($format)
{
    return date($format);
}

function randomNumber($length)
{
    $result = '';
    for ($i = 0; $i < $length; $i++) {
        $result .= mt_rand(0, 9);
    }
    return $result;
}

function get_contact()
{
    $CI = get_instance();
    $contact = $CI->db->select('email2 as process_technology_email, email3 as high_pressure_pump_email, contact1 as process_technology_contact, contact2 as high_pressure_pump_contact')->get('contact_us')->row();
    return $contact;
}

function get_pages()
{
    $CI = get_instance();
    $contact = $CI->db->select('title,slug')->where('status', 1)->get('pages')->result_array();
    return $contact;
}

function get_social_links()
{
    $CI = get_instance();
    $contact = $CI->db->select('name,link,icon')->where('status', 1)->order_by('sequence', 'asc')->get('social_link')->result_array();
    return $contact;
}
