<?php

function getSessionData($type)
{
    $CI = get_instance();
    $data = array();
    $where = array();
    $table = "";
    $sessData = $CI->session->userdata($type);

    if ($type == 'admin') {
        $select = "id,name,email,profile_image,mobile";
        $table = "admin_login";
        $where['id'] = $sessData['id'];
    } elseif ($type == 'instructor') {
        $select = "id,username,category_name,subcategory_name,contact1,email1,profile_image";
        $table = "instructor";
        $where['id'] = $sessData['id'];
    } elseif ($type == 'student') {
        $select = "id,full_name,gender,email,profile_image,phone";
        $table = "students";
        $where['login_token'] = $sessData['login_token'];
        $where['status'] = 1;
    }

    if (!empty($table) && isset($sessData['id']) && !empty($sessData['id']) && !empty($where)) {
        $checkUser = $CI->db->select($select)->where($where)->get($table)->row_array();
        if (isset($checkUser) && !empty($checkUser)) {
            $data = $checkUser;
        }
    }
    return $data;
}

function getBrowser()
{
    $CI = get_instance();
    $CI->load->library("geolib/geolib");

    $data = array();
    $data = $CI->geolib->user_agent();
    return $data;
}

function getUserLocationDetails()
{
    $CI = get_instance();
    $CI->load->library("geolib/geolib");

    $data = array();
    $data_insert = array();
    $insertArr = array();
    $data = $CI->geolib->ip_info();
    $insertArr = array('geoplugin_request', 'geoplugin_city', 'geoplugin_region', 'geoplugin_regionCode', 'geoplugin_regionName', 'geoplugin_countryCode', 'geoplugin_countryName', 'geoplugin_continentName', 'geoplugin_latitude', 'geoplugin_longitude', 'geoplugin_locationAccuracyRadius', 'geoplugin_timezone', 'geoplugin_currencyCode');
    foreach ($insertArr as $val) {
        if (isset($data[$val]) && !empty($data[$val])) {
            $data_insert[$val] = $data[$val];
        }
    }
    $data = $data_insert;
    return $data;
}


function maskPhoneNumber($phone_number)
{
    return substr($phone_number, 0, 2) . "*****" . substr($phone_number, -3);
}

function maskEmailAddress($email_addres)
{
    return substr($email_addres, 0, 4) . '***' . substr($email_addres, strpos($email_addres, "@"));
}

function login_location()
{

    $curl = curl_init();

    $url = "http://www.geoplugin.net/json.gp";
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CUSTOMREQUEST => 'GET'
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    if (!empty($response)) {
        $response = json_decode($response, true);
    }
    if (isset($response['geoplugin_credit'])) {
        unset($response['geoplugin_credit']);
    }
    $location_data = array();
    $location_data['ip_address'] = (isset($response['geoplugin_request']) && !empty($response['geoplugin_request']) ? $response['geoplugin_request'] : get_client_ip());
    $location_array = array();
    $location_array['city'] = (isset($response['geoplugin_city']) && !empty($response['geoplugin_city']) ? $response['geoplugin_city'] : "");
    $location_array['state'] = (isset($response['geoplugin_region']) && !empty($response['geoplugin_region']) ? $response['geoplugin_region'] : (isset($response['geoplugin_regionName']) && !empty($response['geoplugin_regionName']) ? $response['geoplugin_regionName'] : ""));
    $location_array['country'] = (isset($response['geoplugin_countryName']) && !empty($response['geoplugin_countryName']) ? $response['geoplugin_countryName'] : "");
    $location_data['location'] = implode(", ", $location_array);
    return $location_data;
}


function get_login_browser_detail()
{
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version = "";
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    } elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    } elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    }

    if (preg_match('/MSIE/i', $u_agent) && !preg_match('/Opera/i', $u_agent)) {
        $bname = 'Internet Explorer';
        $ub = "MSIE";
    } else if (preg_match('/Firefox/i', $u_agent)) {
        $bname = 'Mozilla Firefox';
        $ub = "Firefox";
    } else if (preg_match('/OPR/i', $u_agent)) {
        $bname = 'Opera';
        $ub = "Opera";
    } else if (preg_match('/Chrome/i', $u_agent) && !preg_match('/Edge/i', $u_agent)) {
        $bname = 'Google Chrome';
        $ub = "Chrome";
    } else if (preg_match('/Safari/i', $u_agent) && !preg_match('/Edge/i', $u_agent)) {
        $bname = 'Apple Safari';
        $ub = "Safari";
    } else if (preg_match('/Netscape/i', $u_agent)) {
        $bname = 'Netscape';
        $ub = "Netscape";
    } else if (preg_match('/Edge/i', $u_agent)) {
        $bname = 'Edge';
        $ub = "Edge";
    } else if (preg_match('/Trident/i', $u_agent)) {
        $bname = 'Internet Explorer';
        $ub = "MSIE";
    }

    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) . ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
    }

    $i = count($matches['browser']);
    if ($i != 1) {
        if (strripos($u_agent, "Version") < strripos($u_agent, $ub)) {
            $version = $matches['version'][0];
        } else {
            $version = $matches['version'][1];
        }
    } else {
        $version = $matches['version'][0];
    }

    if ($version == null || $version == "") {
        $version = "?";
    }

    return array(
        'userAgent' => $u_agent,
        'name'      => $bname,
        'version'   => $version,
        'platform'  => $platform,
        'pattern'    => $pattern
    );
}

function otp_url_verification_code()
{
    return mt_rand(11111, 99999) . time();
}
