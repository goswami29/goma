<?php $this->load->view('admin/include/header'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">
                    <?php echo $page_title; ?>
                </h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12"><?php $this->load->view('alert_error'); ?></div>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="post" action="" enctype="multipart/form-data">
                        <div class="row">
                            <input type="hidden" name="id" value="<?php echo (isset($show_data['id']) && !empty($show_data['id']) ? $show_data['id'] : ""); ?>">
                            <div class="col-lg-6 form-group">
                                <label>Main Title</label>
                                <input type="text" name="main_title" class="form-control" value="<?php echo (isset($show_data['main_title']) && !empty($show_data['main_title']) ? $show_data['main_title'] : ""); ?>" required="">
                            </div>
                            <div class="col-lg-6 form-group">
                                <label>SEO Title</label>
                                <input type="text" name="seo_title" class="form-control" value="<?php echo (isset($show_data['seo_title']) && !empty($show_data['seo_title']) ? $show_data['seo_title'] : ""); ?>">
                            </div>
                            <div class="col-lg-6 form-group">
                                <label>SEO Keyword</label>
                                <textarea type="text" class="form-control" rows="3" name="seo_keyword"><?php echo (isset($show_data['seo_keyword']) && !empty($show_data['seo_keyword']) ? $show_data['seo_keyword'] : ""); ?></textarea>
                            </div>
                            <div class="col-lg-6 form-group">
                                <label>SEO Meta Tag</label>
                                <textarea type="text" class="form-control" rows="3" name="seo_meta_tag"><?php echo (isset($show_data['seo_meta_tag']) && !empty($show_data['seo_meta_tag']) ? $show_data['seo_meta_tag'] : ""); ?></textarea>
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>About Heading</label>
                                <textarea type="text" class="form-control" rows="3" name="heading"><?php echo (isset($show_data['heading']) && !empty($show_data['heading']) ? $show_data['heading'] : ""); ?></textarea>
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Sub heading</label>
                                <textarea type="text" class="form-control" rows="3" name="subheading"><?php echo (isset($show_data['subheading']) && !empty($show_data['subheading']) ? $show_data['subheading'] : ""); ?></textarea>
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Button Title</label>
                                <input type="text" name="button_title" class="form-control" value="<?php echo (isset($show_data['button_title']) && !empty($show_data['button_title']) ? $show_data['button_title'] : ""); ?>">
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Button URL</label>
                                <input type="text" name="button_url" class="form-control" value="<?php echo (isset($show_data['button_url']) && !empty($show_data['button_url']) ? $show_data['button_url'] : ""); ?>">
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>About Background Image</label>
                                <div class="col-sm-10">
                                    <label class="custom-file">
                                        <input type="file" name="image" class="">
                                    </label>
                                    <div style="color: red">[1920 X 740 pixels]</div>
                                </div>
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Uploded About Background Image</label>
                                <div class="col-sm-10">
                                    <?php if ($show_data['image'] != '' && !empty($show_data['image'])) { ?>
                                        <div class="bannerShow">
                                            <img src="<?php echo base_url('uploads/about/' . $show_data['image']); ?>" class="img-thumbnail" alt="current" /><br /><?php echo "current file"; ?>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="col-lg-3 form-group">
                                <label>Vision Image</label>
                                <div class="col-sm-10">
                                    <label class="custom-file">
                                        <input type="file" name="vision_image" class="">
                                    </label>
                                    <div style="color: red">[900 X 750 pixels]</div>
                                </div>
                            </div>

                            <div class="col-lg-3 form-group">
                                <label>Uploded Vision Image</label>
                                <div class="col-sm-12">
                                    <?php if ($show_data['vision_image'] != '' && !empty($show_data['vision_image'])) { ?>
                                        <div class="bannerShow">
                                            <img src="<?php echo base_url('uploads/about/' . $show_data['vision_image']); ?>" class="img-thumbnail" alt="current" /><br /><?php echo "current file"; ?>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Vision Description</label>
                                <textarea type="text" class="form-control ckeditor" rows="5" name="vision_desc"><?php echo (isset($show_data['vision_desc']) && !empty($show_data['vision_desc']) ? $show_data['vision_desc'] : ""); ?></textarea>
                            </div>


                            <div class="col-lg-3 form-group">
                                <label>Mission Image</label>
                                <div class="col-sm-10">
                                    <label class="custom-file">
                                        <input type="file" name="mission_image" class="">
                                    </label>
                                    <div style="color: red">[900 X 750 pixels]</div>
                                </div>
                            </div>

                            <div class="col-lg-3 form-group">
                                <label>Uploded Mission Image</label>
                                <div class="col-sm-12">
                                    <?php if ($show_data['mission_image'] != '' && !empty($show_data['mission_image'])) { ?>
                                        <div class="bannerShow">
                                            <img src="<?php echo base_url('uploads/about/' . $show_data['mission_image']); ?>" class="img-thumbnail" alt="current" /><br /><?php echo "current file"; ?>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Mission Description</label>
                                <textarea type="text" class="form-control ckeditor" rows="5" name="mission_desc"><?php echo (isset($show_data['mission_desc']) && !empty($show_data['mission_desc']) ? $show_data['mission_desc'] : ""); ?></textarea>
                            </div>


                            <div class="col-lg-3 form-group">
                                <label>Company Image</label>
                                <div class="col-sm-10">
                                    <label class="custom-file">
                                        <input type="file" name="company_image" class="">
                                    </label>
                                    <div style="color: red">[900 X 750 pixels]</div>
                                </div>
                            </div>

                            <div class="col-lg-3 form-group">
                                <label>Uploded Company Image</label>
                                <div class="col-sm-12">
                                    <?php if ($show_data['company_image'] != '' && !empty($show_data['company_image'])) { ?>
                                        <div class="bannerShow">
                                            <img src="<?php echo base_url('uploads/about/' . $show_data['company_image']); ?>" class="img-thumbnail" alt="current" /><br /><?php echo "current file"; ?>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Overview of the company description</label>
                                <textarea type="text" class="form-control ckeditor" rows="5" name="company_desc"><?php echo (isset($show_data['company_desc']) && !empty($show_data['company_desc']) ? $show_data['company_desc'] : ""); ?></textarea>
                            </div>

                            <div class="col-md-12 pb-3">
                                <button type="submit" class="btn btn-success">Save Data</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('admin/include/footer'); ?>