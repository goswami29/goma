<?php $this->load->view('admin/include/header'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">
                    <?php echo $page_title . (isset($show_data['title']) && !empty($show_data['title']) ? ' / ' . $show_data['title'] : ''); ?>
                    <a href="<?php echo site_url($redirect_url); ?>" class="btn btn-sm btn-info ml-3 float-right mt-3">Back To List</a>
                </h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12"><?php $this->load->view('alert_error'); ?></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="post" action="" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-lg-3 form-group">
                                <label>Status</label>
                                <select class="form-control" name="status" autocomplete="off">
                                    <option value="1" <?php echo (isset($show_data['status']) && ($show_data['status'] == 1) ? "selected" : ""); ?>>Active</option>
                                    <option value="0" <?php echo (isset($show_data['status']) && ($show_data['status'] == 0) ? "selected" : ""); ?>>De-active</option>
                                </select>
                            </div>


                            <div class="col-lg-3 form-group">
                                <label>Select Year</label>
                                <select class="form-control" name="year" required="">
                                    <option value="">Select Year</option>
                                    <?php for ($i = '1981'; $i <= 2025; $i++) { ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Milestone Description</label>
                                <textarea type="text" name="short_desc" class="form-control" rows="3" placeholder="Milestone Description" required=""><?php echo (isset($show_data['short_desc']) && !empty($show_data['short_desc']) ? $show_data['short_desc'] : ""); ?></textarea>
                            </div>

                            <div class="col-md-12 pb-3">
                                <button type="submit" class="btn btn-success">Save Data</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('admin/include/footer'); ?>