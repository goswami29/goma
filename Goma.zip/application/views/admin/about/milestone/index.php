<?php $this->load->view('admin/include/header'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title"><?php echo $page_title; ?>
                    <a href="<?php echo site_url('admin/milestones/add'); ?>" class="btn btn-info mr-2 float-right mt-3">Add Milestone</a>
                </h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12"><?php $this->load->view('alert_error'); ?></div>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php
                    $starts_from = ($per_page * ($page - 1)) + 1;
                    $end_to = $starts_from + $per_page - 1;
                    if ($end_to > $num_rows) {
                        $end_to = $num_rows;
                    }
                    $entries_text = "Showing " . $starts_from . " to " . $end_to . " of " . $num_rows . " entries";
                    ?>
                    <p class="text-heading font-16"><?php echo $entries_text; ?></p>
                    <div class="table-responsive">
                        <table class="table table-sm table-centered mb-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>Short</th>
                                    <th>Year</th>
                                    <th width="50%">Milestone Description</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="banner_sortable">
                                <?php
                                if (!empty($list)) {
                                    $i = 1;
                                    foreach ($list as $list_val) {
                                ?>
                                        <tr id="banner-<?php echo $list_val['id']; ?>">
                                            <td class="handle">
                                                <a class="btn default" style="cursor:move"> <span class="mdi mdi-arrow-all"></span></a>
                                            </td>
                                            <td><?php echo $list_val['year']; ?></td>
                                            <td><?php echo word_limiter($list_val['short_desc'], 20); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm <?php echo ($list_val['status'] == 1) ? "btn-success" : "btn-danger" ?>" title="status"><?php echo ($list_val['status'] == 1) ? "Active" : "De-active" ?></button>
                                            </td>
                                            <td class="table-action">
                                                <a href="<?php echo site_url('admin/milestones/edit/' . safe_b64encode(rand(11111111, 99999999) . $list_val['id'])); ?>" class="action-icon text-info" title="Edit data"> <i class="mdi mdi-pencil"></i></a>
                                                <a href="<?php echo site_url('admin/milestones/delete/' . safe_b64encode(rand(11111111, 99999999) . $list_val['id'])); ?>" class="action-icon text-danger" onclick="return areyousure();" title="Delete data"> <i class="mdi mdi-delete"></i></a>
                                            </td>
                                        </tr>
                                    <?php
                                        $i++;
                                    }
                                } else {
                                    ?>
                                    <tr>
                                        <td>
                                            <h4 class="header-title">No data found</h4>
                                        </td>
                                    </tr>
                                <?php } ?>

                            </tbody>
                        </table>
                    </div>
                    <?php echo pagination($num_rows, $per_page, $page, $url); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('admin/include/footer'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        create_sortable();
    });

    function create_sortable() {
        $('#banner_sortable').sortable({
            scroll: true,
            axis: 'y',
            handle: '.handle',
            update: function() {
                save_sortable();
            }
        });
    }

    function save_sortable() {
        serial = $('#banner_sortable').sortable('serialize');
        console.log(serial);
        $.ajax({
            url: '<?php echo site_url('admin/milestones/organize'); ?>',
            type: 'POST',
            data: serial
        });
    }
</script>

<script type="text/javascript">
    function areyousure() {
        return confirm('Do you want to delete this record');
    }
</script>