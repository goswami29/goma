<?php $this->load->view('admin/include/header'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">
                    <?php echo $page_title . (isset($show_data['title']) && !empty($show_data['title']) ? ' / ' . $show_data['title'] : ''); ?>
                    <a href="<?php echo site_url($redirect_url); ?>" class="btn btn-sm btn-info ml-3 float-right mt-3">Back To List</a>
                </h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12"><?php $this->load->view('alert_error'); ?></div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="post" action="" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-lg-4 form-group">
                                <label>Status</label>
                                <select class="form-control" name="status" autocomplete="off">
                                    <option value="1" <?php echo (isset($show_data['status']) && ($show_data['status'] == 1) ? "selected" : ""); ?>>Active</option>
                                    <option value="0" <?php echo (isset($show_data['status']) && ($show_data['status'] == 0) ? "selected" : ""); ?>>De-active</option>
                                </select>
                            </div>
                            <div class="col-lg-4 form-group">
                                <label>Title</label>
                                <input type="text" name="name" class="form-control" placeholder="Title" value="<?php echo (isset($show_data['name']) && !empty($show_data['name']) ? $show_data['name'] : ""); ?>" required="">
                            </div>

                            <div class="col-lg-4 form-group">
                                <label>Designation</label>
                                <input type="text" name="designation" class="form-control" placeholder="Designation" value="<?php echo (isset($show_data['designation']) && !empty($show_data['designation']) ? $show_data['designation'] : ""); ?>">
                            </div>

                            <div class="col-lg-12 form-group">
                                <label>Linkedin Profile</label>
                                <input type="text" name="linkedin" class="form-control" placeholder="Linkedin Profile" value="<?php echo (isset($show_data['linkedin']) && !empty($show_data['linkedin']) ? $show_data['linkedin'] : ""); ?>">
                            </div>

                            <div class="col-lg-6 form-group">
                                <label>Icon Image</label>
                                <div class="col-sm-10">
                                    <label class="custom-file">
                                        <input type="file" name="image" class="">
                                    </label>
                                    <div style="color: red">[400 X 400 pixels]</div>
                                </div>
                            </div>

                            <div class="col-md-12 pb-3">
                                <button type="submit" class="btn btn-success">Save Data</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('admin/include/footer'); ?>