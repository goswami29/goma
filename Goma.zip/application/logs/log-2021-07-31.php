<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-31 14:07:41 --> Severity: error --> Exception: syntax error, unexpected '}' C:\wamp64\www\goma\application\views\admin\process_technology\category\list.php 56
ERROR - 2021-07-31 14:22:14 --> Severity: error --> Exception: Call to a member function update_data() on null C:\wamp64\www\goma\application\controllers\admin\Categories.php 66
ERROR - 2021-07-31 14:24:01 --> Severity: error --> Exception: Call to a member function update_data() on null C:\wamp64\www\goma\application\controllers\admin\Categories.php 66
ERROR - 2021-07-31 14:31:29 --> Severity: error --> Exception: Call to a member function update_data() on null C:\wamp64\www\goma\application\controllers\admin\Categories.php 67
ERROR - 2021-07-31 15:33:15 --> 404 Page Not Found: Uploads/category
ERROR - 2021-07-31 16:09:44 --> 404 Page Not Found: admin/Equipments/index
ERROR - 2021-07-31 17:25:55 --> 404 Page Not Found: Uploads/service
ERROR - 2021-07-31 17:28:01 --> 404 Page Not Found: Uploads/service
ERROR - 2021-07-31 17:41:23 --> Severity: error --> Exception: Call to a member function get_categories_tierd() on null C:\wamp64\www\goma\application\controllers\admin\Equipments.php 39
ERROR - 2021-07-31 17:46:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Equipment_modal,Category_model C:\wamp64\www\goma\system\core\Loader.php 348
ERROR - 2021-07-31 18:41:46 --> Query error: Unknown column 'e.image cat.name' in 'field list' - Invalid query: SELECT `e`.`id`, `e`.`title`, `e`.`image cat`.`name` as `category_name`
FROM `equipments` as `e`
LEFT JOIN `categories` as `cat` ON `e`.`category_id` = `cat`.`id`
WHERE `deleteflag` = 0
ORDER BY `sequence` ASC
 LIMIT 10
ERROR - 2021-07-31 19:04:12 --> Severity: error --> Exception: Call to undefined function get_student_login_data() C:\wamp64\www\goma\application\controllers\Home.php 7
ERROR - 2021-07-31 19:04:12 --> Severity: error --> Exception: Call to undefined function get_student_login_data() C:\wamp64\www\goma\application\controllers\Home.php 7
ERROR - 2021-07-31 19:04:17 --> Severity: error --> Exception: Call to undefined function get_student_login_data() C:\wamp64\www\goma\application\controllers\Home.php 7
ERROR - 2021-07-31 19:04:29 --> Severity: error --> Exception: Call to undefined function get_student_login_data() C:\wamp64\www\goma\application\controllers\Home.php 7
ERROR - 2021-07-31 19:04:55 --> Severity: error --> Exception: Call to undefined function get_student_login_data() C:\wamp64\www\goma\application\controllers\Home.php 7
ERROR - 2021-07-31 21:27:35 --> 404 Page Not Found: Website/css
ERROR - 2021-07-31 21:29:43 --> 404 Page Not Found: Website/css
ERROR - 2021-07-31 21:31:44 --> 404 Page Not Found: Website/css
