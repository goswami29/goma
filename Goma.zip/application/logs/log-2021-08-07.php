<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-07 11:30:07 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:30:08 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:30:08 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:30:30 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:30:30 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:30:30 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:32:09 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:32:09 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:32:09 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:32:12 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:32:12 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:32:12 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:33:03 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 11:33:03 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 11:33:03 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:33:03 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:33:03 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:33:38 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:33:38 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 11:33:38 --> 404 Page Not Found: Website/fonts
ERROR - 2021-08-07 12:58:57 --> 404 Page Not Found: admin/Process_technology/organize_event
ERROR - 2021-08-07 13:26:55 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:26:55 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:26:55 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:27:27 --> The upload path does not appear to be valid.
ERROR - 2021-08-07 13:27:36 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:31:10 --> 404 Page Not Found: admin/Process_technology/delete_event
ERROR - 2021-08-07 13:44:05 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:44:05 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:44:05 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:44:08 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:44:08 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:44:08 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:44:17 --> The upload path does not appear to be valid.
ERROR - 2021-08-07 13:44:34 --> The upload path does not appear to be valid.
ERROR - 2021-08-07 13:45:41 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:45:42 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:45:42 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:48:08 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 13:48:08 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-07 14:08:49 --> Query error: Unknown column 'image' in 'field list' - Invalid query: SELECT `id`, `event_date_year`, `title`, `event_category`, `place`, `content`, `image`
FROM `process_technology_events`
WHERE `status` = 1
AND `deleteflag` = 0
ERROR - 2021-08-07 16:25:59 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:25:59 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:25:59 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:25:59 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:25:59 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:26:15 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:26:15 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:26:15 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:42:02 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:42:02 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 16:42:02 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-07 17:49:15 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-08-07 17:56:57 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 17:56:57 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 17:56:57 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 17:56:57 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:06:04 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:06:14 --> Severity: error --> Exception: Call to undefined function website_update_date() C:\wamp64\www\goma\application\models\Social_modal.php 90
ERROR - 2021-08-07 18:10:36 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:10:36 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:10:36 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:00 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:00 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:00 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:04 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:22 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:22 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:22 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:24 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:28 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:28 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:32 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:11:38 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:12:00 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-07 18:18:13 --> Query error: Table 'goma_db.contact' doesn't exist - Invalid query: SELECT `email_id1`, `address`, `phone_no`, `mobile_no`, `facebook`, `instagram`, `youtube_url`, `twitter`, `linkedin`, `footer_text`
FROM `contact`
ERROR - 2021-08-07 18:33:58 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:34:09 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:37:07 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:37:22 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:37:33 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:37:48 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:39:25 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:39:31 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:43:06 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-08-07 18:44:18 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-08-07 18:44:40 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-08-07 18:50:50 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:51:04 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:51:08 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:51:15 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:51:56 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:52:14 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:52:35 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 18:52:43 --> 404 Page Not Found: Home/privacy_term_page
ERROR - 2021-08-07 18:56:34 --> Severity: error --> Exception: Call to undefined method Home_modal::page_content() C:\wamp64\www\goma\application\controllers\Home.php 425
ERROR - 2021-08-07 18:56:43 --> Severity: error --> Exception: Call to undefined method Home_modal::page_content() C:\wamp64\www\goma\application\controllers\Home.php 425
ERROR - 2021-08-07 19:17:37 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 19:17:42 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 19:17:57 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 19:18:09 --> 404 Page Not Found: Website/css
ERROR - 2021-08-07 19:21:11 --> 404 Page Not Found: Website/css
