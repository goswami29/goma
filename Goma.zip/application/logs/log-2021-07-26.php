<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-26 10:41:40 --> 404 Page Not Found: admin/Contact_us/delete
ERROR - 2021-07-26 10:55:07 --> Severity: error --> Exception: Too few arguments to function Contactus_modal::view_enquiry(), 0 passed in C:\wamp64\www\goma\application\controllers\admin\Contact_us.php on line 71 and exactly 1 expected C:\wamp64\www\goma\application\models\Contactus_modal.php 110
ERROR - 2021-07-26 10:56:17 --> Severity: error --> Exception: Too few arguments to function Contactus_modal::view_enquiry(), 0 passed in C:\wamp64\www\goma\application\controllers\admin\Contact_us.php on line 71 and exactly 1 expected C:\wamp64\www\goma\application\models\Contactus_modal.php 110
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:26 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:46:28 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-26 11:56:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Regional_offices_modal C:\wamp64\www\goma\system\core\Loader.php 348
ERROR - 2021-07-26 11:56:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Regional_offices_modal C:\wamp64\www\goma\system\core\Loader.php 348
ERROR - 2021-07-26 14:56:07 --> Query error: Unknown column 'sequence' in 'order clause' - Invalid query: SELECT *
FROM `regional_offices`
WHERE `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-07-26 15:18:49 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `regional_offices` SET `office_type` = Array, `region` = '2', `title` = 'Process Technology Equipment - West Region', `contact_person` = 'Bharat', `phone_no1` = '09090123456', `phone_no2` = '09090123456', `email1` = 'bharat.digiinterface@gmail.com', `email2` = 'bharat.digiinterface@gmail.com', `status` = '0', `update_date` = '2021-07-26 03:18:49', `update_by` = '1'
WHERE `id` = '2'
ERROR - 2021-07-26 17:31:08 --> 404 Page Not Found: Serviceshtml/index
ERROR - 2021-07-26 17:55:16 --> 404 Page Not Found: Services/index
ERROR - 2021-07-26 18:16:50 --> 404 Page Not Found: Uploads/about
ERROR - 2021-07-26 18:17:31 --> 404 Page Not Found: Uploads/about
ERROR - 2021-07-26 19:08:48 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 19:08:55 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 19:20:18 --> 404 Page Not Found: Home/contact_us
ERROR - 2021-07-26 19:20:19 --> 404 Page Not Found: Home/contact_us
ERROR - 2021-07-26 19:20:19 --> 404 Page Not Found: Home/contact_us
ERROR - 2021-07-26 19:30:54 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 19:34:03 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 19:34:08 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 19:35:41 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 19:37:27 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:13:55 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:16:41 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:18:46 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:19:59 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:20:21 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:21:41 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:22:17 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:24:29 --> 404 Page Not Found: Website/css
ERROR - 2021-07-26 21:39:25 --> 404 Page Not Found: admin/Service/view_enquiry
ERROR - 2021-07-26 21:40:31 --> 404 Page Not Found: admin/Service/view_enquiry
