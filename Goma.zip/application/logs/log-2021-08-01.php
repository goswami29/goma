<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-01 15:52:10 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-01 16:23:02 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-01 17:38:13 --> 404 Page Not Found: Uploads/equipments
ERROR - 2021-08-01 17:48:06 --> Severity: error --> Exception: Call to undefined method Systems_modal::get_categories() C:\wamp64\www\goma\application\controllers\admin\Systems.php 40
