<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-06 10:17:21 --> 404 Page Not Found: Uploads/events
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-06 10:17:21 --> 404 Page Not Found: Uploads/events
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-06 10:17:21 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:17:26 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:26:45 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:29:50 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:32:13 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 10:33:17 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:33:17 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:33:17 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:35:57 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:35:57 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:35:57 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:40:19 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:40:19 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:40:19 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:40:30 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:41:25 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:41:38 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:41:58 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:46:33 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:46:33 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:46:33 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:23 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:23 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:23 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:36 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:36 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:36 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:38 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:43 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:43 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:45 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:54 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 10:49:58 --> 404 Page Not Found: Uploads/events
ERROR - 2021-08-06 14:03:40 --> Query error: Unknown column 'slug' in 'field list' - Invalid query: SELECT `id`, `title`, `slug`, `short_desc`, `image`
FROM `events`
WHERE `status` = 1
AND `deleteflag` = 0
ERROR - 2021-08-06 14:05:37 --> Query error: Unknown column 'short_desc' in 'field list' - Invalid query: SELECT `id`, `title`, `slug`, `short_desc`, `image`
FROM `events`
WHERE `status` = 1
AND `deleteflag` = 0
ERROR - 2021-08-06 14:05:51 --> Query error: Unknown column 'short_desc' in 'field list' - Invalid query: SELECT `id`, `title`, `slug`, `short_desc`, `image`
FROM `events`
WHERE `status` = 1
AND `deleteflag` = 0
ERROR - 2021-08-06 14:07:48 --> Query error: Unknown column 'short_desc' in 'field list' - Invalid query: SELECT `id`, `title`, `slug`, `short_desc`, `image`
FROM `events`
WHERE `status` = 1
AND `deleteflag` = 0
ERROR - 2021-08-06 14:08:14 --> Query error: Unknown column 'short_desc' in 'field list' - Invalid query: SELECT `id`, `title`, `slug`, `short_desc`, `image`
FROM `events`
WHERE `status` = 1
AND `deleteflag` = 0
ERROR - 2021-08-06 14:09:45 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:12:26 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:12:55 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:14:36 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:16:47 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:17:44 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:18:01 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:18:20 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:48:37 --> 404 Page Not Found: Home/event_details
ERROR - 2021-08-06 14:51:37 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:54:07 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 14:54:07 --> 404 Page Not Found: Uploads/news
ERROR - 2021-08-06 19:34:25 --> The upload path does not appear to be valid.
ERROR - 2021-08-06 19:57:02 --> The upload path does not appear to be valid.
