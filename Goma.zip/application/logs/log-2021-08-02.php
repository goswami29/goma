<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-02 13:06:07 --> 404 Page Not Found: High-pressure-pumps-and-systemshtml/index
ERROR - 2021-08-02 14:05:31 --> Query error: Unknown column 'deleteflag' in 'where clause' - Invalid query: SELECT *
FROM `pressure_pumps_category`
WHERE `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-02 14:08:43 --> Query error: Unknown column 'sequence' in 'order clause' - Invalid query: SELECT *
FROM `pressure_pumps_category`
WHERE `delete_flag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-02 14:17:09 --> Query error: Unknown column 'title' in 'field list' - Invalid query: INSERT INTO `pressure_pumps_category` (`image`, `title`, `content`, `status`, `add_date`, `add_by`) VALUES ('c9fc9ceffd678fa7ff387cc726fe8ac0.svg', 'Reciprocating Pumps', 'Vivamus tincidunt tortor nec commodo mollis. Phasellus posuere, felis ac ullamcorper vehicula, turpis mi ultrices.', '1', '2021-08-02 02:17:09', '1')
ERROR - 2021-08-02 14:29:45 --> Could not find the language line "form_validation_"
ERROR - 2021-08-02 14:30:50 --> Could not find the language line "form_validation_"
ERROR - 2021-08-02 14:31:53 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 14:32:28 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 14:32:37 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 14:33:36 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 14:34:10 --> Could not find the language line "form_validation_"
ERROR - 2021-08-02 16:24:17 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 16:24:17 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 16:24:17 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 16:24:17 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 16:24:17 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 16:26:48 --> 404 Page Not Found: Uploads/process_technology
ERROR - 2021-08-02 16:42:31 --> 404 Page Not Found: High-pressure-pumps-and-systems/image
ERROR - 2021-08-02 16:42:31 --> 404 Page Not Found: High-pressure-pumps-and-systems/image
ERROR - 2021-08-02 16:42:31 --> 404 Page Not Found: High-pressure-pumps-and-systems/image
ERROR - 2021-08-02 16:42:31 --> 404 Page Not Found: High-pressure-pumps-and-systems/image
ERROR - 2021-08-02 16:42:31 --> 404 Page Not Found: High-pressure-pumps-and-systems/image
ERROR - 2021-08-02 16:42:31 --> 404 Page Not Found: High-pressure-pumps-and-systems/image
ERROR - 2021-08-02 16:50:18 --> Severity: error --> Exception: Call to undefined method Home_modal::pressure_pumps_description() C:\wamp64\www\goma\application\controllers\Home.php 207
ERROR - 2021-08-02 17:23:09 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `id`
FROM `pressure_pumps_category`
WHERE `slug` = 'turnkey-projects-lstk-'
AND `status` = 1
AND `delete_flag` = 0
ERROR - 2021-08-02 17:25:24 --> Query error: Unknown column 'name' in 'field list' - Invalid query: SELECT `id`, `name`, `slug`, `image`
FROM `systems`
WHERE `category_id` = '0'
AND `status` = 1
AND `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-02 18:02:14 --> 404 Page Not Found: Process-technology-and-equipment/dairy
ERROR - 2021-08-02 18:02:19 --> 404 Page Not Found: Process-technology-and-equipment/vegan-products
ERROR - 2021-08-02 18:02:27 --> 404 Page Not Found: Process-technology-and-equipment/fruits-beverage-processing
ERROR - 2021-08-02 18:23:56 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-02 18:37:32 --> 404 Page Not Found: News-listinghtml/index
ERROR - 2021-08-02 18:44:53 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-02 18:44:53 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-02 18:44:53 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-02 18:44:53 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-08-02 18:45:03 --> 404 Page Not Found: admin/Advertisement/index
ERROR - 2021-08-02 18:48:15 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-08-02 18:48:28 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-08-02 19:05:35 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 19:05:35 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 19:05:36 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 19:05:36 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 19:05:36 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 19:06:08 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:14:30 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:14:30 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:14:30 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:14:30 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:14:30 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:16:04 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:16:37 --> Severity: error --> Exception: Call to undefined function website_update_date() C:\wamp64\www\goma\application\models\Home_page_content_modal.php 110
ERROR - 2021-08-02 22:17:18 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:17:18 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:17:18 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:17:18 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:17:18 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:21:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:21:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:21:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:21:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:21:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:30:16 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:30:16 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:30:16 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:30:16 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:30:16 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:31:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:31:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:31:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:31:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:31:34 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:34:32 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:34:32 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:34:32 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:34:32 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:34:32 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:35:22 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:37:54 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:37:54 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:37:54 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:37:54 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:37:54 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:38:21 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:38:21 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:38:21 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:38:21 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:38:43 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:38:43 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:39:35 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:39:35 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:41:40 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:41:40 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:42:41 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:42:41 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:42:59 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:42:59 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:44:21 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:44:21 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:44:33 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:44:33 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:44:40 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:44:40 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:46:24 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:46:24 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:48:37 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:48:37 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:49:17 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:49:17 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:49:41 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:49:41 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:50:31 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:50:31 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:52:25 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:52:49 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:53:03 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:53:14 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:53:23 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:53:37 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 22:59:02 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 23:01:56 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-02 23:03:28 --> 404 Page Not Found: Uploads/home_page
