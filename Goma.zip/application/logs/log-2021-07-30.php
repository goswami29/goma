<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-30 11:43:45 --> 404 Page Not Found: Process-technology-and-equipmenthtml/index
