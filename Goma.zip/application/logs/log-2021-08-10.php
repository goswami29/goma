<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-10 10:36:25 --> 404 Page Not Found: Uplads/index
ERROR - 2021-08-10 11:11:22 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:34:35 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:34:36 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:35:30 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:36:08 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:41:43 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:41:45 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:42:19 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:44:01 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:44:47 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:54:02 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:54:50 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:56:19 --> 404 Page Not Found: Website/css
ERROR - 2021-08-10 11:56:20 --> 404 Page Not Found: Website/css
