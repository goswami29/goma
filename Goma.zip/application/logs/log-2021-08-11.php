<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-11 12:30:42 --> 404 Page Not Found: Website/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-11 12:30:42 --> 404 Page Not Found: Website/js
ERROR - 2021-08-11 12:35:59 --> 404 Page Not Found: Website/css
ERROR - 2021-08-11 12:36:12 --> 404 Page Not Found: Website/css
ERROR - 2021-08-11 12:39:41 --> 404 Page Not Found: Website/css
ERROR - 2021-08-11 12:39:43 --> 404 Page Not Found: Website/css
ERROR - 2021-08-11 12:50:45 --> 404 Page Not Found: Website/css
ERROR - 2021-08-11 12:50:58 --> 404 Page Not Found: Website/css
