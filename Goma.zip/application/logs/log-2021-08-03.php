<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-03 11:09:50 --> 404 Page Not Found: admin/Slider/index
ERROR - 2021-08-03 11:29:59 --> Query error: Table 'goma_db.slider' doesn't exist - Invalid query: SELECT *
FROM `slider`
WHERE `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-03 11:48:07 --> Query error: Unknown column 'short_desc' in 'field list' - Invalid query: INSERT INTO `slider` (`heading`, `short_desc`, `button_title`, `button_url`, `title`, `sub_title`, `status`, `add_date`, `add_by`) VALUES ('Celebrating 4 Decades of Excellence', 'Maintaining an image of excellence for over 35 years is a hard task and Goma has succeeded in exactly that', 'Show More', 'https://www.google.com ', 'Excellence', 'Excellence Mauris non lorem arcu. Praesent et eros diam.', '1', '2021-08-03 11:48:07', '1')
ERROR - 2021-08-03 12:34:16 --> 404 Page Not Found: admin/Awards/index
ERROR - 2021-08-03 13:04:09 --> 404 Page Not Found: Uploads/certifications
ERROR - 2021-08-03 13:04:29 --> 404 Page Not Found: Uploads/certifications
ERROR - 2021-08-03 14:04:31 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 14:07:22 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 14:10:32 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 14:12:42 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 14:15:16 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 14:32:22 --> 404 Page Not Found: Uploads/awards
ERROR - 2021-08-03 15:14:00 --> Severity: error --> Exception: Call to undefined method News_modal::view_blog_seo() C:\wamp64\www\goma\application\controllers\admin\News.php 89
ERROR - 2021-08-03 15:19:08 --> Query error: Table 'goma_db.news_seo' doesn't exist - Invalid query: SELECT *
FROM `news_seo`
ERROR - 2021-08-03 15:30:28 --> Query error: Table 'goma_db.news' doesn't exist - Invalid query: SELECT *
FROM `news`
WHERE `deleteflag` = 0
ERROR - 2021-08-03 15:41:17 --> Query error: Unknown column 'category_id' in 'field list' - Invalid query: INSERT INTO `news` (`image`, `title`, `slug`, `short_desc`, `category_id`, `content`, `news_date`, `status`, `add_date`, `add_by`) VALUES ('7dbd10e5c56308631dd22ba49192b0b2.jpg', 'Cursus nibh libero eu dolor. Praesent vitae rhoncus ligula. Donec fringilla ante velit, id sagittis', 'cursus-nibh-libero-eu-dolor-praesent-vitae-rhoncus-ligula-donec-fringilla-ante-velit-id-sagittis', 'Vivamus tincidunt tortor nec commodo mollis. Phasellus posuere, felis ac ullamcorper vehicula, turpis mi ultrices tellus, at cursus nibh libero eu dolor. Praesent vitae rhoncus ligula. Donec fringilla ante velit, id sagittis purus tincidunt ultrices. Suspendisse potenti. Pellentesque rutrum hendrerit sapien, et sodales justo pulvinar a. Nam pellentesque ut enim et pharetra.', 1, '<p>Vivamus tincidunt tortor nec commodo mollis. Phasellus posuere, felis ac ullamcorper vehicula, turpis mi ultrices tellus, at cursus nibh libero eu dolor. Praesent vitae rhoncus ligula. Donec fringilla ante velit, id sagittis purus tincidunt ultrices. Suspendisse potenti. Pellentesque rutrum hendrerit sapien, et sodales justo pulvinar a. Nam pellentesque ut enim et pharetra.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Vivamus tincidunt tortor nec commodo mollis. Phasellus posuere, felis ac ullamcorper vehicula, turpis mi ultrices tellus, at cursus nibh libero eu dolor. Praesent vitae rhoncus ligula. Donec fringilla ante velit, id sagittis purus tincidunt ultrices. Suspendisse potenti. Pellentesque rutrum hendrerit sapien, et sodales justo pulvinar a. Nam pellentesque ut enim et pharetra.</p>\r\n\r\n<h4>1. Vivamus tincidunt tortor nec commodo</h4>\r\n\r\n<p>mcorper vehicula, turpis mi ultrices tellus, at cursus nibh libero eu dolor. Praesent vitae rhoncus ligula. Donec fringilla ante velit, id sagittis purus tincidunt ultrices. Suspendisse potenti. Pellentesque rutrum hendrerit sapien, et sodales justo pulvinar a. Nam pellentesque ut enim et pharetra.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Vivamus tincidunt tortor nec commodo mollis. Phasellus posuere, felis ac ullamcorper vehicula, turpis mi ultrices tellus, at cursus nibh libero eu dolor. Praesent vitae rhoncus ligula. Donec fringilla ante velit, id sagittis purus tincidunt ultrices. Suspendisse potenti. Pellentesque rutrum hendrerit sapien, et sodales justo pulvinar a. Nam pellentesque ut enim et pharetra.</p>\r\n\r\n<h4>2. Vivamus tincidunt tortor nec commodo</h4>\r\n\r\n<p>&bull; Vivamus tincidunt tortor nec commodo mollis.<br />\r\n&bull; Phasellus posuere, felis ac ullamcorper vehicula.<br />\r\n&bull; Turpis mi ultrices tellus, at cursus nibh libero eu dolor.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Praesent vitae rhoncus ligula. Donec fringilla ante velit, id sagittis purus tincidunt ultrices. Suspendisse potenti. Pellentesque rutrum hendrerit sapien, et sodales justo pulvinar a. Nam pellentesque ut enim et pharetra.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Vivamus tincidunt tortor nec commodo mollis. Phasellus posuere, felis ac ullamcorper vehicula, turpis mi ultrices tellus, at cursus nibh libero eu dolor. Praesent vitae rhoncus ligula.</p>', '2021-08-12', '1', '2021-08-03 03:41:17', '1')
ERROR - 2021-08-03 16:52:16 --> Query error: Unknown column 'b.status' in 'where clause' - Invalid query: SELECT `id`, `title`, `slug`, `short_desc`, `image`
FROM `news`
WHERE `b`.`status` = 1
AND `b`.`deleteflag` = 0
ERROR - 2021-08-03 16:53:46 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 16:56:40 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 16:57:10 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 16:59:46 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:12:16 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:12:16 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:12:16 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:19:26 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:11 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:22:35 --> 404 Page Not Found: News/image
ERROR - 2021-08-03 17:31:42 --> 404 Page Not Found: Uploads/blogs
ERROR - 2021-08-03 18:02:53 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 18:07:21 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 18:10:59 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 18:18:40 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 19:45:59 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-08-03 19:49:38 --> 404 Page Not Found: Website/css
ERROR - 2021-08-03 19:56:33 --> 404 Page Not Found: Website/css
