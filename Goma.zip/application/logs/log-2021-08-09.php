<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-09 13:29:40 --> 404 Page Not Found: Uploads/equipments
ERROR - 2021-08-09 15:07:03 --> Query error: Unknown column 'content' in 'field list' - Invalid query: SELECT `id`, `title`, `content`, `whatsapp_url`, `image`
FROM `systems`
WHERE `category_id` = '1'
AND `status` = 1
AND `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-09 15:07:15 --> Query error: Unknown column 'content' in 'field list' - Invalid query: SELECT `id`, `title`, `content`, `whatsapp_url`, `image`
FROM `equipments`
WHERE `category_id` = '5'
AND `status` = 1
AND `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-09 15:45:39 --> Query error: Unknown column 'content' in 'field list' - Invalid query: SELECT `id`, `title`, `content`, `whatsapp_url`, `image`
FROM `systems`
WHERE `category_id` = '1'
AND `status` = 1
AND `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-09 16:02:51 --> Query error: Unknown column 'content' in 'field list' - Invalid query: SELECT `id`, `title`, `content`, `whatsapp_url`, `image`
FROM `systems`
WHERE `category_id` = '1'
AND `status` = 1
AND `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-09 16:02:59 --> Query error: Unknown column 'content' in 'field list' - Invalid query: SELECT `id`, `title`, `content`, `whatsapp_url`, `image`
FROM `systems`
WHERE `category_id` = '1'
AND `status` = 1
AND `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-09 16:06:32 --> Query error: Unknown column 'whatsapp_url' in 'field list' - Invalid query: SELECT `id`, `title`, `short_desc`, `whatsapp_url`, `image`
FROM `systems`
WHERE `category_id` = '1'
AND `status` = 1
AND `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-09 22:15:41 --> Query error: Unknown column 'content' in 'field list' - Invalid query: SELECT `id`, `title`, `content`, `whatsapp_url`, `image`
FROM `equipments`
WHERE `category_id` = '5'
AND `status` = 1
AND `deleteflag` = 0
ORDER BY `sequence` ASC
ERROR - 2021-08-09 22:26:49 --> 404 Page Not Found: Home/process_technology_equipment_page_description
ERROR - 2021-08-09 22:32:03 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-09 22:33:35 --> 404 Page Not Found: Uploads/pressure_pumps
ERROR - 2021-08-09 23:00:18 --> 404 Page Not Found: Website/css
ERROR - 2021-08-09 23:01:56 --> 404 Page Not Found: Website/css
ERROR - 2021-08-09 23:26:41 --> 404 Page Not Found: Process-technology-and-equipment/dairy
ERROR - 2021-08-09 23:27:37 --> 404 Page Not Found: Process-technology-and-equipment/dairy
