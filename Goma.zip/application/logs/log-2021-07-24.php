<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-24 15:14:53 --> 404 Page Not Found: admin/Profile/index
ERROR - 2021-07-24 15:41:11 --> 404 Page Not Found: admin/Profile/index
ERROR - 2021-07-24 15:49:12 --> Query error: Table 'goma_db.admin_login' doesn't exist - Invalid query: SELECT `name`, `email`, `p`
FROM `admin_login`
WHERE `id` = '1'
ERROR - 2021-07-24 17:01:44 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-24 17:01:44 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-24 17:05:48 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-24 17:05:48 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-24 17:34:11 --> Query error: Table 'goma_db.website_update' doesn't exist - Invalid query: UPDATE `website_update` SET `update_date` = '2021-07-24'
WHERE `id` = 1
ERROR - 2021-07-24 17:36:09 --> 404 Page Not Found: admin/Contact_enquiry/index
ERROR - 2021-07-24 17:48:29 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-07-24 17:48:29 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-07-24 17:48:29 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-07-24 17:48:29 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-07-24 17:49:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:08 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:08 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:08 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-24 17:49:08 --> 404 Page Not Found: Uploads/faq
