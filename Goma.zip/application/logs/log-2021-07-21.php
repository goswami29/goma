<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-21 16:54:08 --> Query error: Table 'goma_db.user_roles' doesn't exist - Invalid query: SELECT c.id,c.name,c.email,c1.name as role_name FROM users as c LEFT JOIN user_roles as c1 ON c.id = c1.id WHERE c.id = '1'
ERROR - 2021-07-21 16:54:12 --> Query error: Table 'goma_db.user_roles' doesn't exist - Invalid query: SELECT c.id,c.name,c.email,c1.name as role_name FROM users as c LEFT JOIN user_roles as c1 ON c.id = c1.id WHERE c.id = '1'
ERROR - 2021-07-21 16:54:23 --> 404 Page Not Found: admin/Logout/index
ERROR - 2021-07-21 16:54:32 --> Query error: Table 'goma_db.user_roles' doesn't exist - Invalid query: SELECT c.id,c.name,c.email,c1.name as role_name FROM users as c LEFT JOIN user_roles as c1 ON c.id = c1.id WHERE c.id = '1'
ERROR - 2021-07-21 16:54:50 --> Query error: Table 'goma_db.user_roles' doesn't exist - Invalid query: SELECT c.id,c.name,c.email,c1.name as role_name FROM users as c LEFT JOIN user_roles as c1 ON c.id = c1.id WHERE c.id = '1'
ERROR - 2021-07-21 17:02:18 --> 404 Page Not Found: admin/Chapter/index
ERROR - 2021-07-21 17:10:23 --> Query error: Table 'goma_db.menus' doesn't exist - Invalid query: SELECT `id`, `parent`, `action`, `name`, `slug`, `url`, `icon`
FROM `menus`
WHERE `status` = '1'
AND `parent` = '0'
AND `delete_flag` = '0'
ORDER BY `orders` asc
ERROR - 2021-07-21 17:15:03 --> 404 Page Not Found: admin/Chapters/index
ERROR - 2021-07-21 17:15:34 --> 404 Page Not Found: admin/Webinar/index
ERROR - 2021-07-21 17:16:12 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-07-21 17:16:12 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-07-21 17:16:12 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-07-21 17:16:12 --> 404 Page Not Found: Uploads/social_link
ERROR - 2021-07-21 17:16:17 --> 404 Page Not Found: admin/Prospectus/index
ERROR - 2021-07-21 17:16:22 --> 404 Page Not Found: Uploads/advertisement
ERROR - 2021-07-21 17:16:22 --> 404 Page Not Found: Uploads/advertisement
ERROR - 2021-07-21 17:16:22 --> 404 Page Not Found: Uploads/advertisement
ERROR - 2021-07-21 17:16:22 --> 404 Page Not Found: Uploads/advertisement
ERROR - 2021-07-21 17:16:27 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 17:16:27 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:16:27 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:16:27 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:16:27 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:16:42 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-07-21 17:16:42 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-07-21 17:16:42 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-07-21 17:16:42 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-07-21 17:16:42 --> 404 Page Not Found: Uploads/home_page
ERROR - 2021-07-21 17:17:38 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:17:38 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:17:38 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:19:04 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:19:04 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:19:04 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:19:07 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:19:09 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:19:09 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:19:09 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:20:08 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 17:20:11 --> Query error: Table 'goma_db.courses' doesn't exist - Invalid query: SELECT `r`.*, `c`.`name` as `course_name`
FROM `result` as `r`
LEFT JOIN `courses` as `c` ON `c`.`id` = `r`.`course_id`
WHERE `r`.`delete_flag` = 0
ORDER BY `r`.`sequence` ASC
 LIMIT 50
ERROR - 2021-07-21 17:23:29 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:23:29 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:23:29 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 17:23:29 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:23:29 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:23:58 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 17:24:28 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:24:28 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 17:24:28 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:24:28 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:24:28 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:24:35 --> Query error: Table 'goma_db.courses' doesn't exist - Invalid query: SELECT `c`.*, `coures`.`name` as `course_name`
FROM `membership` as `c`
LEFT JOIN `courses` as `coures` ON `c`.`course_id` = `coures`.`id`
WHERE `c`.`delete_flag` = 0
ORDER BY `orders` asc
 LIMIT 100
ERROR - 2021-07-21 17:25:18 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 17:25:18 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:25:18 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:25:18 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:25:19 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:25:23 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 17:25:23 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:25:23 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:25:23 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:25:23 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 17:27:49 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:27:49 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:27:49 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:27:52 --> 404 Page Not Found: admin/Tags/index
ERROR - 2021-07-21 17:43:50 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:43:50 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:43:50 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:43:53 --> Query error: Unknown column 'r.id' in 'field list' - Invalid query: SELECT `r`.`id`
FROM `tags`
WHERE `delete_flag` = 0
ERROR - 2021-07-21 17:44:07 --> Query error: Table 'goma_db.courses' doesn't exist - Invalid query: SELECT *
FROM `courses`
WHERE `status` = 1
ERROR - 2021-07-21 17:59:09 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:59:09 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 17:59:09 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:08:59 --> Query error: Table 'goma_db.website_update' doesn't exist - Invalid query: UPDATE `website_update` SET `update_date` = '2021-07-21'
WHERE `id` = 1
ERROR - 2021-07-21 18:30:11 --> 404 Page Not Found: admin/Blogs/index
ERROR - 2021-07-21 18:31:02 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:31:02 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:31:02 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:31:04 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:37:56 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:37:56 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:37:56 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:37:58 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 18:42:17 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 19:20:03 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 19:20:03 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 19:20:03 --> 404 Page Not Found: Uploads/events
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:47:43 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:01 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:48:07 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 19:48:39 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 19:48:39 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 19:48:39 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 19:48:39 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 19:48:39 --> 404 Page Not Found: Uploads/membership
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:48 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:48:51 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:00 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-21 19:49:08 --> 404 Page Not Found: Uploads/advertisement
ERROR - 2021-07-21 19:49:08 --> 404 Page Not Found: Uploads/advertisement
ERROR - 2021-07-21 19:49:08 --> 404 Page Not Found: Uploads/advertisement
ERROR - 2021-07-21 19:49:08 --> 404 Page Not Found: Uploads/advertisement
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:07 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:09 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:50:11 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 19:54:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Team_modal C:\wamp64\www\goma\system\core\Loader.php 348
ERROR - 2021-07-21 19:55:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Team_modal C:\wamp64\www\goma\system\core\Loader.php 348
ERROR - 2021-07-21 20:07:00 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 20:07:39 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 20:07:52 --> 404 Page Not Found: Uploads/faq
ERROR - 2021-07-21 20:12:00 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 20:12:38 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 20:12:40 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 20:13:52 --> 404 Page Not Found: Uploads/banners
ERROR - 2021-07-21 20:15:40 --> 404 Page Not Found: Uploads/banners
