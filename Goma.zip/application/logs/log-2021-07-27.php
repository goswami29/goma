<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-27 17:14:46 --> 404 Page Not Found: Blog/index
ERROR - 2021-07-27 17:14:51 --> 404 Page Not Found: Website/css
ERROR - 2021-07-27 17:14:58 --> 404 Page Not Found: Blog/index
ERROR - 2021-07-27 17:15:05 --> 404 Page Not Found: Website/css
ERROR - 2021-07-27 17:15:10 --> 404 Page Not Found: Website/css
ERROR - 2021-07-27 17:15:14 --> 404 Page Not Found: Website/css
ERROR - 2021-07-27 17:33:39 --> Severity: error --> Exception: Call to undefined method Home_modal::blog() C:\wamp64\www\goma\application\controllers\Home.php 96
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:02:14 --> 404 Page Not Found: Uploads/testimonial
ERROR - 2021-07-27 18:23:35 --> The upload path does not appear to be valid.
ERROR - 2021-07-27 18:43:30 --> 404 Page Not Found: admin/Blogs/image
ERROR - 2021-07-27 18:43:30 --> 404 Page Not Found: admin/Blogs/image
ERROR - 2021-07-27 18:49:15 --> 404 Page Not Found: Blog/latest-news-headline
ERROR - 2021-07-27 19:03:06 --> Severity: error --> Exception: Call to undefined method Home_modal::blog_details() C:\wamp64\www\goma\application\controllers\Home.php 122
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:06:44 --> 404 Page Not Found: Blog/image
ERROR - 2021-07-27 19:35:23 --> 404 Page Not Found: Upload/blogs
ERROR - 2021-07-27 19:35:23 --> 404 Page Not Found: Upload/blogs
